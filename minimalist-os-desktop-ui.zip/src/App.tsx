import { useEffect } from "react";
import { loadSettings } from "./os/settings";
import { Desktop } from "./shell/Desktop";

/** Entry point: load persisted settings, then hand over to the desktop shell. */
export default function App() {
  useEffect(() => {
    loadSettings();
  }, []);
  return <Desktop />;
}
