/**
 * Tiny arithmetic evaluator (recursive descent, no eval).
 *
 *   expr    = term   { ("+" | "-") term }
 *   term    = unary  { ("*" | "/") unary }
 *   unary   = "-" unary | postfix
 *   postfix = primary { "%" }          (x% = x / 100)
 *   primary = number | "(" expr ")"
 *
 * Pure and dependency free: portable to any runtime.
 */

export class CalcError extends Error {}

const TOKEN = /\s*(\d+\.?\d*|\.\d+|[-+*/%()])/y;

function tokenize(src: string): string[] {
  const out: string[] = [];
  TOKEN.lastIndex = 0;
  let pos = 0;
  while (pos < src.length) {
    TOKEN.lastIndex = pos;
    const m = TOKEN.exec(src);
    if (!m) throw new CalcError("Unexpected input");
    out.push(m[1]);
    pos = TOKEN.lastIndex;
  }
  return out;
}

export function evaluate(src: string): number {
  const t = tokenize(src);
  let i = 0;
  const peek = () => t[i];

  function primary(): number {
    const tok = t[i++];
    if (tok === undefined) throw new CalcError("Unexpected end");
    if (tok === "(") {
      const v = expr();
      if (t[i++] !== ")") throw new CalcError("Missing )");
      return v;
    }
    const n = Number(tok);
    if (Number.isNaN(n)) throw new CalcError("Unexpected " + tok);
    return n;
  }
  function postfix(): number {
    let v = primary();
    while (peek() === "%") {
      i++;
      v /= 100;
    }
    return v;
  }
  function unary(): number {
    if (peek() === "-") {
      i++;
      return -unary();
    }
    return postfix();
  }
  function term(): number {
    let v = unary();
    while (peek() === "*" || peek() === "/") {
      const op = t[i++];
      const r = unary();
      if (op === "/" && r === 0) throw new CalcError("Division by zero");
      v = op === "*" ? v * r : v / r;
    }
    return v;
  }
  function expr(): number {
    let v = term();
    while (peek() === "+" || peek() === "-") {
      const op = t[i++];
      const r = term();
      v = op === "+" ? v + r : v - r;
    }
    return v;
  }

  const result = expr();
  if (i < t.length) throw new CalcError("Unexpected " + t[i]);
  if (!Number.isFinite(result)) throw new CalcError("Out of range");
  return result;
}

/** Trim floating-point noise (0.1+0.2 -> 0.3) and format. */
export function formatResult(n: number): string {
  const r = parseFloat(n.toPrecision(12));
  return Object.is(r, -0) ? "0" : String(r);
}

/** Make a half-typed expression evaluable: drop trailing operator, close parens. */
export function complete(expr: string): string {
  let s = expr.replace(/[-+*/.]+$/, "");
  const open = (s.match(/\(/g) ?? []).length - (s.match(/\)/g) ?? []).length;
  if (open > 0) s += ")".repeat(open);
  return s;
}
