import { useState } from "react";
import { cn } from "../../utils/cn";
import { isTypingTarget, useWindowKeys } from "../../ui/hooks";
import type { AppManifest, AppProps } from "../types";
import { complete, evaluate, formatResult } from "./eval";

const OPS = "+-*/";
const show = (s: string) => s.replace(/\*/g, "×").replace(/\//g, "÷").replace(/-/g, "−");

interface Calc {
  expr: string;
  prev: string; // previous "expression =" line
  fresh: boolean; // expr is a finished result
  error: boolean;
}

const INIT: Calc = { expr: "", prev: "", fresh: false, error: false };

function press(s: Calc, key: string): Calc {
  if (s.error && key !== "C") return key === "⌫" ? INIT : press(INIT, key);
  const last = s.expr.slice(-1);
  const endsDigit = /\d$/.test(s.expr);

  if (key === "C") return INIT;

  if (key === "⌫") {
    return { ...s, expr: s.expr.slice(0, -1), fresh: false };
  }

  if (key === "=") {
    if (!s.expr) return s;
    try {
      const src = complete(s.expr);
      if (!src) return s;
      const res = formatResult(evaluate(src));
      return { expr: res, prev: show(src) + " =", fresh: true, error: false };
    } catch {
      return { ...s, error: true };
    }
  }

  if (key === "±") {
    if (!s.expr) return s;
    const wrapped = s.expr.match(/\(-(\d+\.?\d*|\.\d+)\)$/);
    if (wrapped) return { ...s, expr: s.expr.slice(0, wrapped.index) + wrapped[1], fresh: false };
    const num = s.expr.match(/(\d+\.?\d*|\.\d+)$/);
    if (!num) return s;
    return { ...s, expr: s.expr.slice(0, num.index) + "(-" + num[1] + ")", fresh: false };
  }

  if (/^\d$/.test(key)) {
    if (s.fresh) return { ...INIT, expr: key };
    // avoid "007": replace a lone leading zero of the current number
    if (/(^|[^\d.])0$/.test(s.expr)) return { ...s, expr: s.expr.slice(0, -1) + key };
    if (last === ")" || last === "%") return { ...s, expr: s.expr + "*" + key };
    return { ...s, expr: s.expr + key };
  }

  if (key === ".") {
    if (s.fresh) return { ...INIT, expr: "0." };
    if (endsDigit) {
      const cur = s.expr.match(/[\d.]+$/)![0];
      return cur.includes(".") ? s : { ...s, expr: s.expr + "." };
    }
    return { ...s, expr: s.expr + "0." };
  }

  if (key === "%") {
    return endsDigit || last === ")" ? { ...s, expr: s.expr + "%", fresh: false } : s;
  }

  if (key === "(") {
    if (s.fresh) return { ...INIT, expr: "(" };
    return { ...s, expr: s.expr + (endsDigit || last === ")" || last === "%" ? "*(" : "(") };
  }
  if (key === ")") {
    const open = (s.expr.match(/\(/g) ?? []).length - (s.expr.match(/\)/g) ?? []).length;
    return open > 0 && (endsDigit || last === ")" || last === "%") ? { ...s, expr: s.expr + ")" } : s;
  }

  if (OPS.includes(key)) {
    if (!s.expr) return key === "-" ? { ...s, expr: "-" } : s;
    if (last === "(") return key === "-" ? { ...s, expr: s.expr + "-" } : s;
    if (OPS.includes(last)) {
      // replace operator; a lone leading "-" cannot be replaced
      if (s.expr.length === 1) return s;
      return { ...s, expr: s.expr.slice(0, -1) + key };
    }
    if (last === ".") return { ...s, expr: s.expr.slice(0, -1) + key, fresh: false };
    return { ...s, expr: s.expr + key, fresh: false };
  }
  return s;
}

const ROWS: string[][] = [
  ["C", "⌫", "%", "/"],
  ["7", "8", "9", "*"],
  ["4", "5", "6", "-"],
  ["1", "2", "3", "+"],
  ["±", "0", ".", "="],
];

function Calculator({ focused }: AppProps) {
  const [s, setS] = useState<Calc>(INIT);
  const input = (k: string) => setS((cur) => press(cur, k));

  useWindowKeys(focused, (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey || isTypingTarget(e.target)) return;
    const k = e.key;
    let mapped: string | null = null;
    if (/^\d$/.test(k)) mapped = k;
    else if (k === "," || k === ".") mapped = ".";
    else if ("+-*/%()".includes(k) && k.length === 1) mapped = k;
    else if (k === "x" || k === "X") mapped = "*";
    else if (k === "Enter" || k === "=") mapped = "=";
    else if (k === "Backspace") mapped = "⌫";
    else if (k === "Escape" || k === "Delete" || k === "c" || k === "C") mapped = "C";
    if (mapped) {
      e.preventDefault();
      input(mapped);
    }
  });

  // live preview of the running result
  let preview = "";
  if (!s.error && !s.fresh && /[-+*/%]/.test(s.expr.replace(/^-/, "").replace(/\(-/g, "("))) {
    try {
      const src = complete(s.expr);
      if (src) preview = "= " + formatResult(evaluate(src));
    } catch {
      /* incomplete expression: no preview */
    }
  }

  const text = s.error ? "Error" : show(s.expr) || "0";
  const small = text.length > 14;

  return (
    <div className="h-full flex flex-col bg-surface p-2 gap-2">
      <div className="border border-line bg-surface px-2 py-1 h-[72px] flex flex-col justify-end items-end overflow-hidden" aria-live="polite">
        <div className="h-4 text-[11px] text-fg-dim truncate max-w-full">{s.prev || preview}</div>
        <div
          className={cn(
            "font-mono truncate max-w-full leading-8",
            small ? "text-base" : "text-2xl",
            s.error && "text-danger",
          )}
          style={{ direction: "ltr" }}
        >
          {text}
        </div>
      </div>
      <div className="flex-1 grid grid-cols-4 grid-rows-5 gap-1 min-h-0">
        {ROWS.flat().map((k) => {
          const isOp = "/*-+".includes(k);
          return (
            <button
              key={k}
              onClick={() => input(k)}
              aria-label={k === "⌫" ? "Delete" : k === "C" ? "Clear" : undefined}
              className={cn(
                "border text-sm font-mono min-h-0",
                k === "="
                  ? "bg-sel text-sel-fg border-sel"
                  : isOp || k === "C" || k === "⌫" || k === "%"
                    ? "bg-surface-2 border-line hover:bg-surface-3"
                    : "bg-surface border-line hover:bg-surface-3",
              )}
            >
              {isOp ? show(k) : k}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export const calculator: AppManifest = {
  id: "calculator",
  name: "Calculator",
  description: "Basic arithmetic",
  icon: "calc",
  size: { w: 232, h: 340 },
  minSize: { w: 200, h: 290 },
  Component: Calculator,
};
