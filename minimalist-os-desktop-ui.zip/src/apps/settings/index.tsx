import { useEffect, useState, type ReactNode } from "react";
import { OS_CHANNEL, OS_NAME, OS_VERSION } from "../../os/brand";
import { formatDate, formatSize, formatTime } from "../../os/format";
import { services } from "../../os/services";
import type { DisplayMode, SystemInfo } from "../../os/services/system";
import { DEFAULT_SETTINGS, SETTINGS_PATH, updateSettings, useSettings } from "../../os/settings";
import { SHORTCUTS } from "../../os/shortcuts";
import { Button, Segmented, inputCls } from "../../ui/controls";
import { useNow } from "../../ui/hooks";
import { Icon, type IconName } from "../../ui/Icon";
import { cn } from "../../utils/cn";
import type { AppManifest } from "../types";

/* ---------- layout helpers ---------- */

function Pane({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="text-sm font-medium mb-2">{title}</h2>
      <div className="border-t border-line">{children}</div>
    </section>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex items-start gap-3 py-2 border-b border-line">
      <div className="w-36 shrink-0 pt-0.5">
        <div>{label}</div>
        {hint && <div className="text-[11px] text-fg-dim">{hint}</div>}
      </div>
      <div className="flex-1 min-w-0">{children}</div>
    </div>
  );
}

function Note({ children }: { children: ReactNode }) {
  return <p className="mt-2 text-[11px] text-fg-dim">{children}</p>;
}

function Check({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="inline-flex items-center gap-2">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}

/* ---------- panes ---------- */

const WALLPAPERS = [
  ["Slate", "#3f4446"],
  ["Graphite", "#202223"],
  ["Black", "#000000"],
  ["Stone", "#a9a79f"],
  ["Paper", "#dcdad2"],
  ["Moss", "#4b5a4f"],
  ["Steel", "#475563"],
  ["Clay", "#6b5a52"],
] as const;

function Appearance() {
  const s = useSettings();
  return (
    <Pane title="Appearance">
      <Field label="Theme">
        <Segmented
          value={s.theme}
          onChange={(theme) => updateSettings({ theme })}
          options={[
            { value: "light", label: "Light" },
            { value: "dark", label: "Dark" },
          ]}
        />
      </Field>
      <Field label="Wallpaper" hint="Solid colour">
        <div className="flex flex-wrap gap-1.5">
          {WALLPAPERS.map(([name, hex]) => (
            <button
              key={hex}
              title={name}
              aria-label={name}
              aria-pressed={s.wallpaper === hex}
              onClick={() => updateSettings({ wallpaper: hex })}
              style={{ background: hex }}
              className={cn(
                "w-8 h-6 border",
                s.wallpaper === hex ? "outline outline-2 outline-offset-1 outline-fg border-line" : "border-line-strong",
              )}
            />
          ))}
        </div>
        <div className="flex items-center gap-2 mt-2">
          <input
            type="color"
            value={s.wallpaper}
            onChange={(e) => updateSettings({ wallpaper: e.target.value })}
            aria-label="Custom wallpaper colour"
            className="w-8 h-6 p-0 border border-line bg-transparent"
          />
          <span className="font-mono text-[11px] text-fg-dim">{s.wallpaper}</span>
          <Button className="ml-auto" onClick={() => updateSettings({ wallpaper: DEFAULT_SETTINGS.wallpaper })}>
            Default
          </Button>
        </div>
      </Field>
    </Pane>
  );
}

const key = (m: DisplayMode) => `${m.width}x${m.height}@${m.refreshHz}`;

function Display() {
  const [modes, setModes] = useState<DisplayMode[]>([]);
  const [current, setCurrent] = useState<DisplayMode | null>(null);
  const [pick, setPick] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    services.display.listModes().then(setModes);
    services.display.currentMode().then(setCurrent);
  }, []);

  const apply = async () => {
    const m = modes.find((x) => key(x) === pick);
    if (!m) return;
    const r = await services.display.setMode(m);
    setMsg(r.ok ? "Resolution changed." : (r.reason ?? "Could not change resolution."));
  };

  return (
    <Pane title="Display">
      <Field label="Current mode">{current ? `${current.width} × ${current.height} @ ${current.refreshHz} Hz` : <span className="text-fg-dim">Unknown (no display driver)</span>}</Field>
      <Field label="Resolution" hint="Available modes">
        <div className="border border-line max-w-64">
          {modes.map((m) => (
            <label
              key={key(m)}
              className={cn("h-6 px-2 flex items-center gap-2", pick === key(m) ? "bg-sel text-sel-fg" : "hover:bg-surface-2")}
            >
              <input type="radio" name="mode" checked={pick === key(m)} onChange={() => setPick(key(m))} />
              {m.width} × {m.height}
              <span className="ml-auto text-[11px] opacity-70">{m.refreshHz} Hz</span>
            </label>
          ))}
        </div>
        <div className="mt-2 flex items-center gap-2">
          <Button primary disabled={!pick} onClick={apply}>
            Apply
          </Button>
          {msg && <span className="text-[11px] text-fg-dim">{msg}</span>}
        </div>
      </Field>
      <Note>Display backend: {services.display.backend}. Mode list is a placeholder until the display subsystem reports real modes.</Note>
    </Pane>
  );
}

const LAYOUTS = [
  ["us", "English (US)"],
  ["uk", "English (UK)"],
  ["de", "German"],
  ["fr", "French"],
  ["es", "Spanish"],
  ["dvorak", "Dvorak"],
];

function Keyboard() {
  const s = useSettings();
  return (
    <Pane title="Keyboard">
      <Field label="Layout">
        <select value={s.keyboardLayout} onChange={(e) => updateSettings({ keyboardLayout: e.target.value })} className={cn(inputCls, "w-48")}>
          {LAYOUTS.map(([v, n]) => (
            <option key={v} value={v}>
              {n}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Repeat delay" hint={`${s.keyRepeatDelayMs} ms`}>
        <input type="range" min={150} max={1000} step={50} value={s.keyRepeatDelayMs} onChange={(e) => updateSettings({ keyRepeatDelayMs: +e.target.value })} className="w-48" />
      </Field>
      <Field label="Repeat rate" hint={`${s.keyRepeatRate} / s`}>
        <input type="range" min={2} max={40} value={s.keyRepeatRate} onChange={(e) => updateSettings({ keyRepeatRate: +e.target.value })} className="w-48" />
      </Field>
      <Note>Layout and repeat values are saved now and will be applied by the input subsystem once it exists.</Note>
      <h3 className="mt-4 mb-1 font-medium">Shortcuts</h3>
      <div className="border-t border-line">
        {SHORTCUTS.map((sc) => (
          <div key={sc.id} className="h-6 flex items-center gap-3 border-b border-line">
            <kbd className="w-36 shrink-0 font-mono text-[11px]">{sc.keys}</kbd>
            <span className="text-fg-dim">{sc.description}</span>
          </div>
        ))}
      </div>
    </Pane>
  );
}

function DateTime() {
  const s = useSettings();
  const now = useNow(1000);
  return (
    <Pane title="Date & Time">
      <Field label="Current time" hint="Read-only">
        <span className="font-mono">
          {formatDate(now, "iso")} {formatTime(now, true, true)}
        </span>
        <Note>Setting the system clock needs a real time service; this control is intentionally absent until one exists.</Note>
      </Field>
      <Field label="Clock format">
        <Segmented
          value={s.clock24 ? "24" : "12"}
          onChange={(v) => updateSettings({ clock24: v === "24" })}
          options={[
            { value: "24", label: "24-hour" },
            { value: "12", label: "12-hour" },
          ]}
        />
        <div className="mt-2">
          <Check checked={s.showSeconds} onChange={(showSeconds) => updateSettings({ showSeconds })} label="Show seconds" />
        </div>
      </Field>
      <Field label="Date format">
        <select value={s.dateFormat} onChange={(e) => updateSettings({ dateFormat: e.target.value as typeof s.dateFormat })} className={cn(inputCls, "w-48")}>
          {(["short", "long", "iso", "dmy", "mdy"] as const).map((f) => (
            <option key={f} value={f}>
              {formatDate(now, f)}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Week starts on">
        <Segmented
          value={String(s.weekStart) as "0" | "1"}
          onChange={(v) => updateSettings({ weekStart: v === "0" ? 0 : 1 })}
          options={[
            { value: "1", label: "Monday" },
            { value: "0", label: "Sunday" },
          ]}
        />
      </Field>
    </Pane>
  );
}

function uptime(sec: number) {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return `${d ? d + "d " : ""}${h}h ${m}m`;
}

function System() {
  const [info, setInfo] = useState<SystemInfo | null>(null);
  useEffect(() => {
    services.system.info().then(setInfo);
  }, []);
  const na = <span className="text-fg-dim">Not available</span>;
  const val = (v: string | null) => (v ? v : na);
  const mem = (used: number | null, total: number | null) =>
    total === null ? na : `${used === null ? "?" : formatSize(used)} / ${formatSize(total)}`;
  return (
    <Pane title="System">
      {info && (
        <>
          <Field label="Operating system">{`${info.osName} ${info.osVersion}`}</Field>
          <Field label="Hostname">{val(info.hostname)}</Field>
          <Field label="Kernel">{val(info.kernel)}</Field>
          <Field label="Architecture">{val(info.arch)}</Field>
          <Field label="Processor">{val(info.cpu)}</Field>
          <Field label="Memory">{mem(info.memoryUsed, info.memoryTotal)}</Field>
          <Field label="Storage">{mem(info.storageUsed, info.storageTotal)}</Field>
          <Field label="Uptime">{info.uptimeSec === null ? na : uptime(info.uptimeSec)}</Field>
        </>
      )}
      <Field label="Service backends">
        <div className="font-mono text-[11px] space-y-0.5 text-fg-dim">
          <div>system: {services.system.backend}</div>
          <div>fs: {services.fs.backend}</div>
          <div>display: {services.display.backend}</div>
          <div>power: {services.power.backend}</div>
        </div>
      </Field>
      <Note>Values the backend cannot supply are shown as “Not available” rather than invented.</Note>
    </Pane>
  );
}

function About() {
  return (
    <Pane title="About">
      <div className="py-3 flex items-center gap-3 border-b border-line">
        <div className="w-10 h-10 bg-sel text-sel-fg grid place-items-center">
          <Icon name="logo" size={24} />
        </div>
        <div>
          <div className="text-sm font-medium">{OS_NAME}</div>
          <div className="text-fg-dim">
            Version {OS_VERSION} ({OS_CHANNEL})
          </div>
        </div>
      </div>
      <Field label="What this is">
        The desktop shell, window manager and built-in applications for a small operating system. This build is the UI layer only: there is no kernel, and it is not a bootable system.
      </Field>
      <Field label="Settings file">
        <span className="font-mono text-[11px]">{SETTINGS_PATH}</span>
      </Field>
      <Field label="Licences">
        Written from scratch for this project. Runtime libraries: React (MIT). Build-time only: Vite (MIT), Tailwind CSS (MIT). See docs/OPEN_SOURCE.md.
      </Field>
    </Pane>
  );
}

/* ---------- app ---------- */

const CATEGORIES: { id: string; name: string; icon: IconName; View: () => ReactNode }[] = [
  { id: "appearance", name: "Appearance", icon: "appearance", View: Appearance },
  { id: "display", name: "Display", icon: "monitor", View: Display },
  { id: "keyboard", name: "Keyboard", icon: "keyboard", View: Keyboard },
  { id: "datetime", name: "Date & Time", icon: "clock", View: DateTime },
  { id: "system", name: "System", icon: "chip", View: System },
  { id: "about", name: "About", icon: "info", View: About },
];

function Settings() {
  const [cat, setCat] = useState("appearance");
  const { View } = CATEGORIES.find((c) => c.id === cat)!;
  return (
    <div className="h-full flex bg-surface">
      <nav className="w-36 shrink-0 border-r border-line bg-surface-2 p-1" aria-label="Settings categories">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setCat(c.id)}
            className={cn("w-full h-6 px-2 flex items-center gap-2 text-left", cat === c.id ? "bg-sel text-sel-fg" : "hover:bg-surface-3")}
          >
            <Icon name={c.icon} size={13} />
            {c.name}
          </button>
        ))}
      </nav>
      <div className="flex-1 min-w-0 overflow-auto p-4">
        <View />
      </div>
    </div>
  );
}

export const settings: AppManifest = {
  id: "settings",
  name: "Settings",
  description: "Appearance, display, keyboard, time",
  icon: "settings",
  size: { w: 600, h: 420 },
  minSize: { w: 460, h: 300 },
  singleton: true,
  Component: Settings,
};
