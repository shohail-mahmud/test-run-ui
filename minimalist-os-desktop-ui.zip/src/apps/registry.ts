import { calculator } from "./calculator";
import { calendar } from "./calendar";
import { files } from "./files";
import { settings } from "./settings";
import { textEditor } from "./text";
import type { AppManifest } from "./types";

/**
 * Built-in applications. Order = launcher order (Alt+1, Alt+2, ...).
 * To add an app: create a folder with a manifest and list it here.
 */
export const APPS: AppManifest[] = [files, calculator, calendar, textEditor, settings];

export const getApp = (id: string) => APPS.find((a) => a.id === id);
