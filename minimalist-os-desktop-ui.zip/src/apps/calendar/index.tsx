import { useEffect, useMemo, useRef, useState } from "react";
import { DAYS_SHORT, MONTHS, formatDate, ymd } from "../../os/format";
import { describeFsError } from "../../os/services";
import { useSettings } from "../../os/settings";
import { Button, IconButton, inputCls } from "../../ui/controls";
import { isTypingTarget, useNow, useWindowKeys } from "../../ui/hooks";
import { Icon } from "../../ui/Icon";
import { cn } from "../../utils/cn";
import type { AppManifest, AppProps } from "../types";
import { EVENTS_PATH, loadEvents, newId, saveEvents, type CalEvent } from "./store";

const parse = (s: string) => {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d);
};
const addDays = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const byTime = (a: CalEvent, b: CalEvent) => (a.time ?? "").localeCompare(b.time ?? "") || a.title.localeCompare(b.title);

function Calendar({ focused }: AppProps) {
  const settings = useSettings();
  const now = useNow(30_000);
  const todayKey = ymd(now);

  const [selected, setSelected] = useState(todayKey);
  const [view, setView] = useState(() => ({ y: now.getFullYear(), m: now.getMonth() }));
  const [events, setEvents] = useState<CalEvent[]>([]);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [time, setTime] = useState("");
  const [notes, setNotes] = useState("");
  const titleRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadEvents()
      .then((e) => setEvents(e))
      .catch((e) => setError(describeFsError(e)))
      .finally(() => setReady(true));
  }, []);

  const commit = (next: CalEvent[]) => {
    setEvents(next);
    saveEvents(next).catch((e) => setError(describeFsError(e)));
  };

  const goto = (key: string) => {
    const d = parse(key);
    setSelected(key);
    setView({ y: d.getFullYear(), m: d.getMonth() });
    resetForm();
  };
  const shiftMonth = (n: number) => {
    setView((v) => {
      const d = new Date(v.y, v.m + n, 1);
      return { y: d.getFullYear(), m: d.getMonth() };
    });
  };

  const cells = useMemo(() => {
    const first = new Date(view.y, view.m, 1);
    const offset = (first.getDay() - settings.weekStart + 7) % 7;
    return Array.from({ length: 42 }, (_, i) => addDays(first, i - offset));
  }, [view, settings.weekStart]);

  const byDate = useMemo(() => {
    const map = new Map<string, CalEvent[]>();
    for (const e of events) {
      const list = map.get(e.date);
      if (list) list.push(e);
      else map.set(e.date, [e]);
    }
    map.forEach((l) => l.sort(byTime));
    return map;
  }, [events]);

  const dayEvents = byDate.get(selected) ?? [];
  const weekdays = Array.from({ length: 7 }, (_, i) => DAYS_SHORT[(i + settings.weekStart) % 7]);

  function resetForm() {
    setEditing(null);
    setTitle("");
    setTime("");
    setNotes("");
  }

  const submit = () => {
    const t = title.trim();
    if (!t) return;
    const data = { title: t, time: time || undefined, notes: notes.trim() || undefined };
    if (editing) commit(events.map((e) => (e.id === editing ? { ...e, ...data } : e)));
    else commit([...events, { id: newId(), date: selected, ...data }]);
    resetForm();
  };

  const startEdit = (e: CalEvent) => {
    setEditing(e.id);
    setTitle(e.title);
    setTime(e.time ?? "");
    setNotes(e.notes ?? "");
    titleRef.current?.focus();
  };

  useWindowKeys(focused, (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey || isTypingTarget(e.target)) return;
    const sel = parse(selected);
    let handled = true;
    if (e.key === "ArrowLeft") goto(ymd(addDays(sel, -1)));
    else if (e.key === "ArrowRight") goto(ymd(addDays(sel, 1)));
    else if (e.key === "ArrowUp") goto(ymd(addDays(sel, -7)));
    else if (e.key === "ArrowDown") goto(ymd(addDays(sel, 7)));
    else if (e.key === "PageUp" || e.key === "PageDown") {
      const n = (e.key === "PageUp" ? -1 : 1) * (e.shiftKey ? 12 : 1);
      const d = new Date(sel.getFullYear(), sel.getMonth() + n, 1);
      const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      goto(ymd(new Date(d.getFullYear(), d.getMonth(), Math.min(sel.getDate(), last))));
    } else if (e.key === "Home" || e.key.toLowerCase() === "t") goto(todayKey);
    else if (e.key.toLowerCase() === "n" || e.key === "Enter") titleRef.current?.focus();
    else handled = false;
    if (handled) e.preventDefault();
  });

  return (
    <div className="h-full flex bg-surface">
      {/* month grid */}
      <div className="flex-1 min-w-0 flex flex-col">
        <div className="flex items-center gap-0.5 p-1 border-b border-line bg-surface-2">
          <IconButton icon="left2" label="Previous year (Shift+PageUp)" onClick={() => shiftMonth(-12)} />
          <IconButton icon="left" label="Previous month (PageUp)" onClick={() => shiftMonth(-1)} />
          <div className="flex-1 text-center font-medium">
            {MONTHS[view.m]} {view.y}
          </div>
          <IconButton icon="right" label="Next month (PageDown)" onClick={() => shiftMonth(1)} />
          <IconButton icon="right2" label="Next year (Shift+PageDown)" onClick={() => shiftMonth(12)} />
          <Button className="ml-1" onClick={() => goto(todayKey)} title="Go to today (T)">
            Today
          </Button>
        </div>
        <div className="grid grid-cols-7 border-b border-line text-[11px] text-fg-dim">
          {weekdays.map((d) => (
            <div key={d} className="h-5 px-1.5 flex items-center">
              {d}
            </div>
          ))}
        </div>
        <div className="flex-1 min-h-0 grid grid-cols-7 grid-rows-6" role="grid">
          {cells.map((d) => {
            const key = ymd(d);
            const inMonth = d.getMonth() === view.m;
            const isToday = key === todayKey;
            const isSel = key === selected;
            const evs = byDate.get(key);
            return (
              <button
                key={key}
                role="gridcell"
                aria-selected={isSel}
                aria-label={formatDate(d, "long")}
                onClick={() => goto(key)}
                className={cn(
                  "min-h-0 min-w-0 border-r border-b border-line p-1 text-left flex flex-col gap-0.5 overflow-hidden",
                  isSel ? "bg-surface-3 outline outline-1 -outline-offset-1 outline-fg" : "hover:bg-surface-2",
                  !inMonth && "text-fg-dim",
                )}
              >
                <span
                  className={cn(
                    "h-4 min-w-4 px-1 inline-flex items-center justify-center self-start leading-none",
                    isToday && "bg-sel text-sel-fg font-medium",
                  )}
                >
                  {d.getDate()}
                </span>
                {evs && (
                  <>
                    <span className="block text-[10px] leading-3 truncate w-full">
                      {evs[0].title}
                    </span>
                    {evs.length > 1 && (
                      <span className="text-[10px] leading-3 text-fg-dim">+{evs.length - 1}</span>
                    )}
                  </>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* day panel */}
      <aside className="w-56 shrink-0 border-l border-line flex flex-col min-h-0">
        <div className="h-7 px-2 flex items-center border-b border-line bg-surface-2 font-medium truncate">
          {formatDate(parse(selected), "long")}
        </div>
        <div className="flex-1 min-h-0 overflow-auto">
          {!ready && <div className="p-2 text-fg-dim">Loading…</div>}
          {ready && dayEvents.length === 0 && <div className="p-2 text-fg-dim">No events</div>}
          {dayEvents.map((e) => (
            <div key={e.id} className={cn("px-2 py-1 border-b border-line group", editing === e.id && "bg-surface-2")}>
              <div className="flex items-start gap-1">
                <div className="flex-1 min-w-0">
                  <div className="truncate">
                    {e.time && <span className="font-mono text-fg-dim mr-1.5">{e.time}</span>}
                    {e.title}
                  </div>
                  {e.notes && <div className="text-[11px] text-fg-dim break-words">{e.notes}</div>}
                </div>
                <IconButton icon="edit" label="Edit event" className="h-5 w-5" onClick={() => startEdit(e)} />
                <IconButton
                  icon="trash"
                  label="Delete event"
                  className="h-5 w-5"
                  onClick={() => {
                    commit(events.filter((x) => x.id !== e.id));
                    if (editing === e.id) resetForm();
                  }}
                />
              </div>
            </div>
          ))}
        </div>
        <form
          className="p-2 border-t border-line bg-surface-2 space-y-1"
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <input
            ref={titleRef}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={(e) => e.key === "Escape" && resetForm()}
            placeholder={editing ? "Edit event" : "New event"}
            aria-label="Event title"
            className={cn(inputCls, "w-full")}
          />
          <div className="flex gap-1">
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              aria-label="Event time"
              className={cn(inputCls, "w-24")}
            />
            <input
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Notes"
              aria-label="Event notes"
              className={cn(inputCls, "flex-1")}
            />
          </div>
          <div className="flex gap-1 justify-end">
            {editing && <Button type="button" onClick={resetForm}>Cancel</Button>}
            <Button type="submit" primary disabled={!title.trim()}>
              <span className="inline-flex items-center gap-1">
                <Icon name={editing ? "check" : "plus"} size={11} />
                {editing ? "Save" : "Add"}
              </span>
            </Button>
          </div>
          <div className="text-[10px] text-fg-dim truncate" title={EVENTS_PATH}>
            {error ? <span className="text-danger">{error}</span> : <>Stored in {EVENTS_PATH.replace(/^.*\/\.local/, "~/.local")}</>}
          </div>
        </form>
      </aside>
    </div>
  );
}

export const calendar: AppManifest = {
  id: "calendar",
  name: "Calendar",
  description: "Month view and events",
  icon: "calendar",
  size: { w: 640, h: 420 },
  minSize: { w: 520, h: 360 },
  singleton: true,
  Component: Calendar,
};
