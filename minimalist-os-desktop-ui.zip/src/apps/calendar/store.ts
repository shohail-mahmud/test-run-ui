/**
 * Calendar event persistence. Events are stored as a JSON document through
 * the FileSystem service, so they live wherever the OS puts user data.
 *
 * Format (version 1):
 *   { "version": 1, "events": [ { id, date: "YYYY-MM-DD", time?: "HH:MM", title, notes? } ] }
 *
 * When the OS gains a real storage/database service, only this file changes.
 */
import { DATA_DIR } from "../../os/brand";
import { services } from "../../os/services";

export interface CalEvent {
  id: string;
  date: string;
  time?: string;
  title: string;
  notes?: string;
}

const DIR = `${DATA_DIR}/calendar`;
const FILE = `${DIR}/events.json`;

export async function loadEvents(): Promise<CalEvent[]> {
  const fs = services.fs;
  if (!(await fs.exists(FILE))) return [];
  const doc = JSON.parse(await fs.readText(FILE));
  return Array.isArray(doc?.events) ? doc.events : [];
}

export async function saveEvents(events: CalEvent[]): Promise<void> {
  const fs = services.fs;
  await fs.mkdir(DIR, { recursive: true });
  await fs.writeText(FILE, JSON.stringify({ version: 1, events }, null, 2));
}

export const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

export const EVENTS_PATH = FILE;
