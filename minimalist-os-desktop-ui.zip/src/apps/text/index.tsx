import { useEffect, useRef, useState } from "react";
import { HOME } from "../../os/brand";
import { basename } from "../../os/path";
import { describeFsError, services } from "../../os/services";
import { IconButton, inputCls } from "../../ui/controls";
import { useWindowKeys } from "../../ui/hooks";
import { cn } from "../../utils/cn";
import type { AppManifest, AppProps } from "../types";

/** Plain-text editor. Reads and writes through `services.fs`. */
function TextEditor({ focused, params, host }: AppProps) {
  const fs = services.fs;
  const initial = typeof params.path === "string" ? params.path : null;
  const [path, setPath] = useState(initial ?? `${HOME}/untitled.txt`);
  const [isNew, setIsNew] = useState(initial === null);
  const [text, setText] = useState("");
  const [saved, setSaved] = useState("");
  const [msg, setMsg] = useState("");
  const [loaded, setLoaded] = useState(initial === null);
  const area = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (initial === null) return;
    let alive = true;
    fs.readText(initial)
      .then((t) => {
        if (!alive) return;
        setText(t);
        setSaved(t);
        setLoaded(true);
      })
      .catch((e) => alive && setMsg(describeFsError(e)));
    return () => {
      alive = false;
    };
  }, [fs, initial]);

  const dirty = text !== saved || (isNew && text !== "");
  useEffect(() => {
    host.setTitle(`${isNew ? "Untitled" : basename(path)}${dirty ? " •" : ""} — Text`);
  }, [host, path, isNew, dirty]);

  const save = async () => {
    try {
      await fs.writeText(path, text);
      setSaved(text);
      setIsNew(false);
      setMsg("Saved");
    } catch (e) {
      setMsg(describeFsError(e));
    }
  };

  useWindowKeys(focused, (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
      e.preventDefault();
      save();
    }
  });

  useEffect(() => {
    if (loaded) area.current?.focus();
  }, [loaded]);

  return (
    <div className="h-full flex flex-col bg-surface">
      <div className="flex items-center gap-1 p-1 border-b border-line bg-surface-2">
        <IconButton icon="save" label="Save (Ctrl+S)" onClick={save} />
        <input
          value={path}
          readOnly={!isNew}
          onChange={(e) => setPath(e.target.value)}
          spellCheck={false}
          aria-label="File path"
          className={cn(inputCls, "flex-1 font-mono", !isNew && "bg-surface-2 border-transparent")}
        />
      </div>
      <textarea
        ref={area}
        value={text}
        disabled={!loaded}
        onChange={(e) => {
          setText(e.target.value);
          setMsg("");
        }}
        spellCheck={false}
        className="flex-1 min-h-0 resize-none p-2 bg-surface outline-none font-mono text-xs leading-5"
      />
      <div className="h-5 shrink-0 border-t border-line bg-surface-2 px-2 flex items-center text-[11px] text-fg-dim">
        <span className={cn(msg && msg !== "Saved" && "text-danger")}>{msg || (dirty ? "Modified" : "")}</span>
        <span className="ml-auto">{text.length} chars</span>
      </div>
    </div>
  );
}

export const textEditor: AppManifest = {
  id: "text",
  name: "Text",
  description: "Plain text editor",
  icon: "text",
  size: { w: 480, h: 340 },
  minSize: { w: 300, h: 180 },
  Component: TextEditor,
};
