import type { ComponentType } from "react";
import type { IconName } from "../ui/Icon";

/**
 * Application contract. An app is a manifest plus a component. It receives a
 * small `host` object for the few things it may ask of the shell, and talks
 * to the OS only through `services` (src/os/services). Apps never import the
 * window manager or the shell, which is what keeps them portable to a future
 * application runtime.
 */
export interface AppHost {
  setTitle(title: string): void;
  close(): void;
  /** Ask the shell to open an app (e.g. the file manager opening a text file). */
  launch(appId: string, params?: Record<string, unknown>): void;
}

export interface AppProps {
  windowId: number;
  /** True while this app's window has input focus. */
  focused: boolean;
  params: Record<string, unknown>;
  host: AppHost;
}

export interface AppManifest {
  id: string;
  name: string;
  description: string;
  icon: IconName;
  size: { w: number; h: number };
  minSize: { w: number; h: number };
  /** Only one window; launching again focuses the existing one. */
  singleton?: boolean;
  Component: ComponentType<AppProps>;
}
