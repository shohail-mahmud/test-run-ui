import { useEffect, useMemo, useRef, useState, type MouseEvent } from "react";
import { HOME } from "../../os/brand";
import { formatDateTime, formatSize } from "../../os/format";
import { basename, dirname, extname, join, normalize, uniqueName } from "../../os/path";
import { describeFsError, services, type FsEntry } from "../../os/services";
import { Button, IconButton, MenuList, Modal, inputCls, type MenuItem } from "../../ui/controls";
import { isTypingTarget, useWindowKeys } from "../../ui/hooks";
import { Icon, type IconName } from "../../ui/Icon";
import { cn } from "../../utils/cn";
import type { AppManifest, AppProps } from "../types";

/**
 * File manager. All filesystem access goes through `services.fs` (the
 * FileSystem interface), so connecting the real OS filesystem requires no
 * change to this file.
 */

const PLACES: { name: string; path: string; icon: IconName }[] = [
  { name: "Home", path: HOME, icon: "home" },
  { name: "Documents", path: `${HOME}/Documents`, icon: "folder" },
  { name: "Downloads", path: `${HOME}/Downloads`, icon: "download" },
  { name: "Pictures", path: `${HOME}/Pictures`, icon: "image" },
  { name: "Temporary", path: "/tmp", icon: "folder" },
  { name: "Computer", path: "/", icon: "drive" },
];

type SortKey = "name" | "size" | "modified";
type Dialog =
  | null
  | { type: "delete"; paths: string[] }
  | { type: "props"; entry: FsEntry; items: number | null }
  | { type: "error"; message: string };
interface Clip {
  mode: "copy" | "cut";
  paths: string[];
}

// Shared by all file-manager windows, like a system clipboard of paths.
let clipboard: Clip | null = null;

function iconFor(e: FsEntry): IconName {
  if (e.kind === "dir") return "folder";
  const x = extname(e.name);
  if (["txt", "md", "log", "json", "conf"].includes(x)) return "text";
  if (["png", "jpg", "jpeg", "gif", "bmp"].includes(x)) return "image";
  return "file";
}

function RenameInput({
  value,
  onChange,
  onCommit,
  onCancel,
}: {
  value: string;
  onChange: (v: string) => void;
  onCommit: () => void;
  onCancel: () => void;
}) {
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.focus();
    const dot = el.value.lastIndexOf(".");
    el.setSelectionRange(0, dot > 0 ? dot : el.value.length);
  }, []);
  return (
    <input
      ref={ref}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      onClick={(e) => e.stopPropagation()}
      onDoubleClick={(e) => e.stopPropagation()}
      onBlur={onCommit}
      onKeyDown={(e) => {
        if (e.key === "Enter") onCommit();
        else if (e.key === "Escape") onCancel();
        e.stopPropagation();
      }}
      className={cn(inputCls, "h-5 flex-1 text-fg bg-surface")}
    />
  );
}

function Files({ focused, params, host }: AppProps) {
  const fs = services.fs;
  const startPath = typeof params.path === "string" ? params.path : HOME;

  const [hist, setHist] = useState({ stack: [startPath], idx: 0 });
  const cwd = hist.stack[hist.idx];
  const [entries, setEntries] = useState<FsEntry[]>([]);
  const [sel, setSel] = useState<string[]>([]);
  const [anchor, setAnchor] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [renameVal, setRenameVal] = useState("");
  const renamingRef = useRef<string | null>(null);
  const [dialog, setDialog] = useState<Dialog>(null);
  const [sort, setSort] = useState<{ key: SortKey; asc: boolean }>({ key: "name", asc: true });
  const [showHidden, setShowHidden] = useState(false);
  const [status, setStatus] = useState("");
  const [pathInput, setPathInput] = useState(cwd);
  const [menu, setMenu] = useState<{ x: number; y: number; onItem: boolean } | null>(null);
  const [clip, setClip] = useState<Clip | null>(clipboard);
  const rootRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  // Load directory + follow filesystem changes
  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const list = await fs.list(cwd);
        if (alive) {
          setEntries(list);
          setStatus("");
        }
      } catch (e) {
        if (alive) {
          setEntries([]);
          setStatus(describeFsError(e));
        }
      }
    };
    load();
    const off = fs.subscribe(load);
    return () => {
      alive = false;
      off();
    };
  }, [fs, cwd]);

  useEffect(() => {
    setPathInput(cwd);
    setSel([]);
    setAnchor(null);
    renamingRef.current = null;
    setRenaming(null);
    host.setTitle(cwd === "/" ? "Files — /" : `Files — ${basename(cwd)}`);
  }, [cwd, host]);

  const visible = useMemo(() => {
    const list = entries.filter((e) => showHidden || !e.name.startsWith("."));
    const dir = sort.asc ? 1 : -1;
    return list.sort((a, b) => {
      if (a.kind !== b.kind) return a.kind === "dir" ? -1 : 1;
      let c = 0;
      if (sort.key === "size") c = a.size - b.size;
      else if (sort.key === "modified") c = a.modified - b.modified;
      if (c === 0) c = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: "base" });
      return c * dir;
    });
  }, [entries, sort, showHidden]);

  // keep the selected row in view when moving with the keyboard
  useEffect(() => {
    const last = sel[sel.length - 1];
    if (!last) return;
    [...(listRef.current?.querySelectorAll<HTMLElement>("[data-path]") ?? [])]
      .find((el) => el.dataset.path === last)
      ?.scrollIntoView({ block: "nearest" });
  }, [sel]);

  const run = async (fn: () => Promise<void>) => {
    try {
      await fn();
    } catch (e) {
      setDialog({ type: "error", message: describeFsError(e) });
    }
  };

  /* ---------- navigation ---------- */
  const go = async (p: string) => {
    const np = normalize(p || "/");
    if (np === cwd) return;
    try {
      const st = await fs.stat(np);
      if (st.kind !== "dir") throw new Error(`Not a folder: ${np}`);
      setHist((h) => ({ stack: [...h.stack.slice(0, h.idx + 1), np], idx: h.idx + 1 }));
    } catch (e) {
      setStatus(describeFsError(e));
      setPathInput(cwd);
    }
  };
  const back = () => setHist((h) => (h.idx > 0 ? { ...h, idx: h.idx - 1 } : h));
  const forward = () => setHist((h) => (h.idx < h.stack.length - 1 ? { ...h, idx: h.idx + 1 } : h));
  const up = () => go(dirname(cwd));

  const open = (en: FsEntry) => {
    if (en.kind === "dir") go(en.path);
    else host.launch("text", { path: en.path });
  };

  /* ---------- selection ---------- */
  const clickRow = (e: MouseEvent, en: FsEntry) => {
    e.stopPropagation();
    const p = en.path;
    if (e.shiftKey && anchor) {
      const a = visible.findIndex((v) => v.path === anchor);
      const b = visible.findIndex((v) => v.path === p);
      if (a >= 0 && b >= 0) {
        setSel(visible.slice(Math.min(a, b), Math.max(a, b) + 1).map((v) => v.path));
        return;
      }
    }
    if (e.ctrlKey || e.metaKey) {
      setSel((s) => (s.includes(p) ? s.filter((x) => x !== p) : [...s, p]));
      setAnchor(p);
      return;
    }
    setSel([p]);
    setAnchor(p);
  };

  const moveSel = (delta: number | "start" | "end") => {
    if (!visible.length) return;
    const last = sel.length ? visible.findIndex((v) => v.path === sel[sel.length - 1]) : -1;
    let i: number;
    if (delta === "start") i = 0;
    else if (delta === "end") i = visible.length - 1;
    else i = Math.max(0, Math.min(visible.length - 1, last < 0 ? (delta > 0 ? 0 : visible.length - 1) : last + delta));
    setSel([visible[i].path]);
    setAnchor(visible[i].path);
  };

  /* ---------- operations ---------- */
  const beginRename = (path: string) => {
    renamingRef.current = path;
    setRenaming(path);
    setRenameVal(basename(path));
  };
  const cancelRename = () => {
    renamingRef.current = null;
    setRenaming(null);
  };
  const commitRename = () => {
    const path = renamingRef.current;
    if (!path) return;
    cancelRename();
    const v = renameVal.trim();
    if (!v || v === basename(path)) return;
    run(async () => {
      const np = await fs.rename(path, v);
      setSel([np]);
      setAnchor(np);
    });
  };

  const newItem = (kind: "file" | "dir") =>
    run(async () => {
      const names = new Set(entries.map((e) => e.name));
      const name = uniqueName(kind === "dir" ? "New folder" : "New file.txt", names, "");
      const path = join(cwd, name);
      if (kind === "dir") await fs.mkdir(path);
      else await fs.writeText(path, "");
      setSel([path]);
      setAnchor(path);
      beginRename(path);
    });

  const setClipboard = (c: Clip | null) => {
    clipboard = c;
    setClip(c);
  };
  const copySel = (mode: "copy" | "cut") => {
    if (sel.length) setClipboard({ mode, paths: [...sel] });
  };
  const paste = () =>
    run(async () => {
      const c = clipboard;
      if (!c) return;
      const names = new Set(entries.map((e) => e.name));
      const created: string[] = [];
      for (const src of c.paths) {
        if (c.mode === "cut" && dirname(src) === cwd) continue;
        const name = uniqueName(basename(src), names);
        names.add(name);
        const dest = join(cwd, name);
        if (c.mode === "copy") await fs.copy(src, dest);
        else await fs.move(src, dest);
        created.push(dest);
      }
      if (c.mode === "cut") setClipboard(null);
      if (created.length) setSel(created);
    });

  const askDelete = () => {
    if (sel.length) setDialog({ type: "delete", paths: [...sel] });
  };
  const doDelete = (paths: string[]) => {
    setDialog(null);
    run(async () => {
      for (const p of paths) await fs.remove(p);
      setSel([]);
    });
  };

  const showProps = () =>
    run(async () => {
      const entry = await fs.stat(sel[0] ?? cwd);
      const items = entry.kind === "dir" ? (await fs.list(entry.path)).length : null;
      setDialog({ type: "props", entry, items });
    });

  /* ---------- keyboard ---------- */
  useWindowKeys(focused, (e) => {
    if (dialog) {
      if (e.key === "Escape") {
        e.preventDefault();
        setDialog(null);
      }
      return;
    }
    if (menu) {
      if (e.key === "Escape") setMenu(null);
      return;
    }
    if (isTypingTarget(e.target)) return;
    if (e.altKey) {
      if (e.key === "ArrowLeft") back();
      else if (e.key === "ArrowRight") forward();
      else if (e.key === "ArrowUp") up();
      else return;
      e.preventDefault();
      return;
    }
    const mod = e.ctrlKey || e.metaKey;
    const key = e.key.toLowerCase();
    let handled = true;
    if (mod && key === "c") copySel("copy");
    else if (mod && key === "x") copySel("cut");
    else if (mod && key === "v") paste();
    else if (mod && key === "a") setSel(visible.map((v) => v.path));
    else if (mod && key === "h") setShowHidden((v) => !v);
    else if (mod) handled = false;
    else if (e.key === "ArrowDown") moveSel(1);
    else if (e.key === "ArrowUp") moveSel(-1);
    else if (e.key === "Home") moveSel("start");
    else if (e.key === "End") moveSel("end");
    else if (e.key === "Enter") {
      const en = visible.find((v) => v.path === sel[0]);
      if (en && sel.length === 1) open(en);
    } else if (e.key === "F2") {
      if (sel.length === 1) beginRename(sel[0]);
    } else if (e.key === "Delete") askDelete();
    else if (e.key === "Backspace") up();
    else if (e.key === "Escape") setSel([]);
    else handled = false;
    if (handled) e.preventDefault();
  });

  /* ---------- context menu ---------- */
  const openMenu = (e: MouseEvent, en: FsEntry | null) => {
    e.preventDefault();
    e.stopPropagation();
    const r = rootRef.current!.getBoundingClientRect();
    if (en && !sel.includes(en.path)) {
      setSel([en.path]);
      setAnchor(en.path);
    }
    setMenu({
      x: Math.max(0, Math.min(e.clientX - r.left, r.width - 180)),
      y: Math.max(0, Math.min(e.clientY - r.top, r.height - (en ? 190 : 130))),
      onItem: !!en,
    });
  };

  const menuItems: MenuItem[] = menu?.onItem
    ? [
        { label: "Open", icon: "folder", hint: "Enter", onClick: () => { const en = visible.find((v) => v.path === sel[0]); if (en) open(en); }, disabled: sel.length !== 1 },
        { separator: true, label: "" },
        { label: "Rename", icon: "rename", hint: "F2", onClick: () => beginRename(sel[0]), disabled: sel.length !== 1 },
        { label: "Copy", icon: "copy", hint: "Ctrl+C", onClick: () => copySel("copy") },
        { label: "Move (cut)", icon: "move", hint: "Ctrl+X", onClick: () => copySel("cut") },
        { label: "Paste", icon: "paste", hint: "Ctrl+V", onClick: paste, disabled: !clip },
        { separator: true, label: "" },
        { label: "Delete", icon: "trash", hint: "Del", danger: true, onClick: askDelete },
        { label: "Properties", icon: "info", onClick: showProps },
      ]
    : [
        { label: "New file", icon: "file-plus", onClick: () => newItem("file") },
        { label: "New folder", icon: "folder-plus", onClick: () => newItem("dir") },
        { separator: true, label: "" },
        { label: "Paste", icon: "paste", hint: "Ctrl+V", onClick: paste, disabled: !clip },
        { label: "Properties", icon: "info", onClick: showProps },
      ];

  const toggleSort = (key: SortKey) =>
    setSort((s) => (s.key === key ? { key, asc: !s.asc } : { key, asc: true }));
  const sortMark = (key: SortKey) => (sort.key === key ? (sort.asc ? " ▲" : " ▼") : "");
  const hasSel = sel.length > 0;
  const oneSel = sel.length === 1;
  const cutSet = new Set(clip?.mode === "cut" ? clip.paths : []);

  return (
    <div ref={rootRef} className="h-full flex flex-col relative bg-surface">
      {/* location bar */}
      <div className="flex items-center gap-0.5 p-1 border-b border-line bg-surface-2">
        <IconButton icon="back" label="Back (Alt+Left)" onClick={back} disabled={hist.idx === 0} />
        <IconButton icon="forward" label="Forward (Alt+Right)" onClick={forward} disabled={hist.idx >= hist.stack.length - 1} />
        <IconButton icon="up" label="Up (Backspace)" onClick={up} disabled={cwd === "/"} />
        <form
          className="flex-1 flex ml-1"
          onSubmit={(e) => {
            e.preventDefault();
            go(pathInput);
          }}
        >
          <input
            value={pathInput}
            onChange={(e) => setPathInput(e.target.value)}
            onBlur={() => setPathInput(cwd)}
            onKeyDown={(e) => e.key === "Escape" && setPathInput(cwd)}
            spellCheck={false}
            aria-label="Location"
            className={cn(inputCls, "flex-1 font-mono")}
          />
        </form>
      </div>

      {/* actions */}
      <div className="flex items-center gap-0.5 px-1 py-0.5 border-b border-line">
        <IconButton icon="file-plus" label="New file" onClick={() => newItem("file")} />
        <IconButton icon="folder-plus" label="New folder" onClick={() => newItem("dir")} />
        <span className="w-px h-4 bg-line mx-1" />
        <IconButton icon="rename" label="Rename (F2)" onClick={() => beginRename(sel[0])} disabled={!oneSel} />
        <IconButton icon="copy" label="Copy (Ctrl+C)" onClick={() => copySel("copy")} disabled={!hasSel} />
        <IconButton icon="move" label="Move: cut (Ctrl+X), then paste in the destination" onClick={() => copySel("cut")} disabled={!hasSel} />
        <IconButton icon="paste" label="Paste (Ctrl+V)" onClick={paste} disabled={!clip} />
        <IconButton icon="trash" label="Delete (Del)" onClick={askDelete} disabled={!hasSel} />
        <span className="w-px h-4 bg-line mx-1" />
        <IconButton icon="info" label="Properties" onClick={showProps} />
        {clip && (
          <span className="ml-2 text-[11px] text-fg-dim truncate">
            {clip.paths.length} to {clip.mode === "cut" ? "move" : "copy"}
          </span>
        )}
      </div>

      <div className="flex-1 min-h-0 flex">
        {/* sidebar */}
        <nav className="w-32 shrink-0 border-r border-line bg-surface-2 p-1 overflow-auto" aria-label="Places">
          {PLACES.map((p) => (
            <button
              key={p.path}
              onClick={() => go(p.path)}
              className={cn(
                "w-full h-6 px-2 flex items-center gap-2 text-left",
                cwd === p.path ? "bg-sel text-sel-fg" : "hover:bg-surface-3",
              )}
            >
              <Icon name={p.icon} size={13} />
              <span className="truncate">{p.name}</span>
            </button>
          ))}
        </nav>

        {/* list */}
        <div className="flex-1 min-w-0 flex flex-col">
          <div className="h-5 shrink-0 flex items-center px-2 gap-2 border-b border-line bg-surface-2 text-[11px] text-fg-dim">
            <button className="flex-1 text-left" onClick={() => toggleSort("name")}>
              Name{sortMark("name")}
            </button>
            <button className="w-16 text-right" onClick={() => toggleSort("size")}>
              Size{sortMark("size")}
            </button>
            <button className="w-28 text-right" onClick={() => toggleSort("modified")}>
              Modified{sortMark("modified")}
            </button>
          </div>
          <div
            ref={listRef}
            role="listbox"
            aria-multiselectable="true"
            className="flex-1 min-h-0 overflow-auto"
            onClick={() => setSel([])}
            onContextMenu={(e) => openMenu(e, null)}
          >
            {visible.map((en) => {
              const selected = sel.includes(en.path);
              return (
                <div
                  key={en.path}
                  role="option"
                  aria-selected={selected}
                  data-path={en.path}
                  onClick={(e) => clickRow(e, en)}
                  onDoubleClick={() => open(en)}
                  onContextMenu={(e) => openMenu(e, en)}
                  className={cn(
                    "h-6 px-2 flex items-center gap-2",
                    selected ? "bg-sel text-sel-fg" : "hover:bg-surface-2",
                    cutSet.has(en.path) && "opacity-50",
                  )}
                >
                  <div className="flex-1 min-w-0 flex items-center gap-2">
                    <Icon name={iconFor(en)} size={13} />
                    {renaming === en.path ? (
                      <RenameInput value={renameVal} onChange={setRenameVal} onCommit={commitRename} onCancel={cancelRename} />
                    ) : (
                      <span className="truncate">{en.name}</span>
                    )}
                  </div>
                  <span className={cn("w-16 text-right text-[11px]", !selected && "text-fg-dim")}>
                    {en.kind === "dir" ? "—" : formatSize(en.size)}
                  </span>
                  <span className={cn("w-28 text-right text-[11px]", !selected && "text-fg-dim")}>
                    {formatDateTime(en.modified)}
                  </span>
                </div>
              );
            })}
            {visible.length === 0 && !status && (
              <div className="p-4 text-fg-dim text-center">This folder is empty</div>
            )}
          </div>
        </div>
      </div>

      {/* status bar */}
      <div className="h-5 shrink-0 border-t border-line bg-surface-2 px-2 flex items-center gap-3 text-[11px] text-fg-dim">
        <span className={cn("truncate", status && "text-danger")}>
          {status || `${visible.length} item${visible.length === 1 ? "" : "s"}${hasSel ? ` · ${sel.length} selected` : ""}`}
        </span>
        <span className="ml-auto truncate" title="Filesystem backend">
          fs: {fs.backend}
        </span>
      </div>

      {menu && (
        <div className="absolute inset-0 z-30" onPointerDown={() => setMenu(null)} onContextMenu={(e) => { e.preventDefault(); setMenu(null); }}>
          <div className="absolute" style={{ left: menu.x, top: menu.y }} onPointerDown={(e) => e.stopPropagation()}>
            <MenuList items={menuItems} onDone={() => setMenu(null)} />
          </div>
        </div>
      )}

      {dialog?.type === "delete" && (
        <Modal
          title="Delete"
          actions={
            <>
              <Button onClick={() => setDialog(null)}>Cancel</Button>
              <Button primary autoFocus onClick={() => doDelete(dialog.paths)}>
                Delete
              </Button>
            </>
          }
        >
          <p>
            {dialog.paths.length === 1
              ? `Delete “${basename(dialog.paths[0])}”?`
              : `Delete ${dialog.paths.length} items?`}
          </p>
          <p className="text-fg-dim">This cannot be undone. Folders are deleted with their contents.</p>
        </Modal>
      )}
      {dialog?.type === "error" && (
        <Modal
          title="Error"
          actions={
            <Button primary autoFocus onClick={() => setDialog(null)}>
              OK
            </Button>
          }
        >
          <p>{dialog.message}</p>
        </Modal>
      )}
      {dialog?.type === "props" && (
        <Modal
          title="Properties"
          actions={
            <Button primary autoFocus onClick={() => setDialog(null)}>
              Close
            </Button>
          }
        >
          <dl className="grid grid-cols-[64px_1fr] gap-x-2 gap-y-1">
            <dt className="text-fg-dim">Name</dt>
            <dd className="break-all">{dialog.entry.name}</dd>
            <dt className="text-fg-dim">Type</dt>
            <dd>{dialog.entry.kind === "dir" ? "Folder" : extname(dialog.entry.name) ? `${extname(dialog.entry.name).toUpperCase()} file` : "File"}</dd>
            <dt className="text-fg-dim">Location</dt>
            <dd className="break-all font-mono text-[11px]">{dirname(dialog.entry.path)}</dd>
            {dialog.items !== null ? (
              <>
                <dt className="text-fg-dim">Contains</dt>
                <dd>{dialog.items} item{dialog.items === 1 ? "" : "s"}</dd>
              </>
            ) : (
              <>
                <dt className="text-fg-dim">Size</dt>
                <dd>
                  {formatSize(dialog.entry.size)} ({dialog.entry.size} bytes)
                </dd>
              </>
            )}
            <dt className="text-fg-dim">Created</dt>
            <dd>{formatDateTime(dialog.entry.created)}</dd>
            <dt className="text-fg-dim">Modified</dt>
            <dd>{formatDateTime(dialog.entry.modified)}</dd>
          </dl>
        </Modal>
      )}
    </div>
  );
}

export const files: AppManifest = {
  id: "files",
  name: "Files",
  description: "Browse and manage files",
  icon: "folder",
  size: { w: 640, h: 400 },
  minSize: { w: 440, h: 260 },
  Component: Files,
};
