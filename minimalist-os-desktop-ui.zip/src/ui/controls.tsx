import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "../utils/cn";
import { Icon, type IconName } from "./Icon";

/** Shared, compact UI primitives. Flat, bordered, 24px tall. */

export function Button({
  className,
  primary,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { primary?: boolean }) {
  return (
    <button
      {...rest}
      className={cn(
        "h-6 px-2.5 border text-xs whitespace-nowrap disabled:opacity-40 disabled:pointer-events-none",
        primary
          ? "bg-sel text-sel-fg border-sel"
          : "bg-surface-2 border-line hover:bg-surface-3 hover:border-line-strong",
        className,
      )}
    />
  );
}

export function IconButton({
  icon,
  label,
  className,
  active,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { icon: IconName; label: string; active?: boolean }) {
  return (
    <button
      {...rest}
      title={label}
      aria-label={label}
      className={cn(
        "h-6 w-6 grid place-items-center border border-transparent hover:bg-surface-3 hover:border-line disabled:opacity-35 disabled:pointer-events-none",
        active && "bg-surface-3 border-line",
        className,
      )}
    >
      <Icon name={icon} />
    </button>
  );
}

export const inputCls =
  "h-6 px-1.5 bg-surface border border-line focus:border-fg outline-none text-xs min-w-0";

export function Modal({
  title,
  children,
  actions,
}: {
  title: string;
  children: ReactNode;
  actions: ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-20 grid place-items-center bg-black/30">
      <div role="dialog" aria-label={title} className="w-72 max-w-[90%] bg-surface border border-line-strong">
        <div className="h-6 px-2 flex items-center border-b border-line bg-surface-2 font-medium">{title}</div>
        <div className="p-3 space-y-2">{children}</div>
        <div className="p-2 pt-0 flex justify-end gap-1.5">{actions}</div>
      </div>
    </div>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="inline-flex border border-line">
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            "h-6 px-3 text-xs",
            o.value === value ? "bg-sel text-sel-fg" : "bg-surface hover:bg-surface-3",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

/** Menu list used by the system menu and context menus. */
export interface MenuItem {
  label: string;
  icon?: IconName;
  hint?: string;
  disabled?: boolean;
  danger?: boolean;
  onClick?: () => void;
  separator?: boolean;
}

export function MenuList({ items, onDone }: { items: MenuItem[]; onDone: () => void }) {
  return (
    <div role="menu" className="bg-surface border border-line-strong py-0.5 min-w-40">
      {items.map((it, i) =>
        it.separator ? (
          <div key={i} className="my-0.5 border-t border-line" />
        ) : (
          <button
            key={i}
            role="menuitem"
            disabled={it.disabled}
            onClick={() => {
              onDone();
              it.onClick?.();
            }}
            className={cn(
              "w-full h-6 px-2 flex items-center gap-2 text-left hover:bg-sel hover:text-sel-fg disabled:opacity-40 disabled:pointer-events-none",
              it.danger && "text-danger hover:text-sel-fg",
            )}
          >
            {it.icon ? <Icon name={it.icon} size={13} /> : <span className="w-[13px]" />}
            <span className="flex-1">{it.label}</span>
            {it.hint && <span className="text-fg-dim text-[11px]">{it.hint}</span>}
          </button>
        ),
      )}
    </div>
  );
}
