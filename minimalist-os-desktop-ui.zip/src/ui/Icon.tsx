import type { ReactNode } from "react";

/**
 * Icon set: 16x16 grid, 1.25px square-capped strokes. One file, no assets,
 * no icon library. Add new glyphs to the map.
 */
const GLYPHS = {
  logo: <path d="M2 3h12v3H9.5v7h-3V6H2z" fill="currentColor" stroke="none" />,
  close: <path d="M3.5 3.5l9 9M12.5 3.5l-9 9" />,
  minimize: <path d="M3.5 12.5h9" />,
  maximize: <rect x="3.5" y="3.5" width="9" height="9" />,
  restore: (
    <>
      <rect x="3.5" y="5.5" width="7" height="7" />
      <path d="M5.5 5.5v-2h7v7h-2" />
    </>
  ),
  calc: (
    <>
      <rect x="3.5" y="1.5" width="9" height="13" />
      <path d="M5.5 4.5h5M5.5 8h1M9.5 8h1M5.5 11h1M9.5 11h1M7.5 8h1M7.5 11h1" />
    </>
  ),
  folder: <path d="M1.5 3.5h4.5l1.5 1.5h7v8h-13z" />,
  file: (
    <>
      <path d="M3.5 1.5h6l3 3v10h-9z" />
      <path d="M9.5 1.5v3h3" />
    </>
  ),
  text: (
    <>
      <path d="M3.5 1.5h6l3 3v10h-9z" />
      <path d="M5.5 8h5M5.5 11h5" />
    </>
  ),
  settings: (
    <>
      <path d="M2 4.5h12M2 11.5h12" />
      <rect x="4" y="3" width="3" height="3" fill="var(--surface)" />
      <rect x="9" y="10" width="3" height="3" fill="var(--surface)" />
    </>
  ),
  calendar: (
    <>
      <rect x="2.5" y="3.5" width="11" height="10" />
      <path d="M2.5 6.5h11M5.5 1.5v3M10.5 1.5v3" />
    </>
  ),
  left: <path d="M10 3.5L5.5 8l4.5 4.5" />,
  right: <path d="M6 3.5L10.5 8 6 12.5" />,
  "left2": <path d="M8.5 3.5L4 8l4.5 4.5M12.5 3.5L8 8l4.5 4.5" />,
  "right2": <path d="M3.5 3.5L8 8l-4.5 4.5M7.5 3.5L12 8l-4.5 4.5" />,
  back: <path d="M13 8H3M7 4L3 8l4 4" />,
  forward: <path d="M3 8h10M9 4l4 4-4 4" />,
  up: <path d="M8 13V3M4 7l4-4 4 4" />,
  plus: <path d="M8 3v10M3 8h10" />,
  "file-plus": (
    <>
      <path d="M3.5 1.5h6l3 3v10h-9z" />
      <path d="M6 9.5h4M8 7.5v4" />
    </>
  ),
  "folder-plus": (
    <>
      <path d="M1.5 3.5h4.5l1.5 1.5h7v8h-13z" />
      <path d="M6 9h4M8 7v4" />
    </>
  ),
  rename: <path d="M2.5 13.5l.7-3 7-7 2.3 2.3-7 7zM9 5l2 2" />,
  copy: (
    <>
      <rect x="5.5" y="5.5" width="8" height="8" />
      <path d="M10.5 5.5v-3h-8v8h3" />
    </>
  ),
  move: <path d="M2 8h12M10 4l4 4-4 4" />,
  paste: (
    <>
      <rect x="3.5" y="3" width="9" height="11" />
      <path d="M6 3V1.5h4V3M6 7h4M6 10h4" />
    </>
  ),
  trash: <path d="M3 4.5h10M6.5 4.5v-2h3v2M4.5 4.5l.5 9h6l.5-9M7 7v4M9 7v4" />,
  info: (
    <>
      <circle cx="8" cy="8" r="6.5" />
      <path d="M8 7.5v4M8 5v.5" />
    </>
  ),
  home: <path d="M2 8l6-5.5L14 8M3.5 7v6.5h9V7M6.5 13.5v-4h3v4" />,
  download: <path d="M8 2v8M4.5 6.5L8 10l3.5-3.5M3 13.5h10" />,
  image: (
    <>
      <rect x="1.5" y="2.5" width="13" height="11" />
      <circle cx="5.5" cy="6" r="1" />
      <path d="M2 12.5l4-4 3 3 2-2 3.5 3.5" />
    </>
  ),
  drive: (
    <>
      <rect x="1.5" y="8.5" width="13" height="5" />
      <path d="M1.5 8.5l2-5h9l2 5M11 11h1.5" />
    </>
  ),
  monitor: (
    <>
      <rect x="1.5" y="2.5" width="13" height="9" />
      <path d="M5.5 14h5M8 11.5V14" />
    </>
  ),
  keyboard: (
    <>
      <rect x="1.5" y="4" width="13" height="8" />
      <path d="M4 7h.5M6.5 7h.5M9 7h.5M11.5 7h.5M4.5 9.5h7" />
    </>
  ),
  clock: (
    <>
      <circle cx="8" cy="8" r="6.5" />
      <path d="M8 4.5V8l2.5 1.5" />
    </>
  ),
  appearance: (
    <>
      <circle cx="8" cy="8" r="6.5" />
      <path d="M8 1.5a6.5 6.5 0 0 1 0 13z" fill="currentColor" />
    </>
  ),
  chip: (
    <>
      <rect x="4.5" y="4.5" width="7" height="7" />
      <path d="M6.5 1.5v3M9.5 1.5v3M6.5 11.5v3M9.5 11.5v3M1.5 6.5h3M1.5 9.5h3M11.5 6.5h3M11.5 9.5h3" />
    </>
  ),
  power: <path d="M8 1.5v6M4.5 3.8a5.5 5.5 0 1 0 7 0" />,
  restart: <path d="M13 8a5 5 0 1 1-1.5-3.5M13 2.5v3h-3" />,
  search: (
    <>
      <circle cx="7" cy="7" r="4.5" />
      <path d="M10.5 10.5l4 4" />
    </>
  ),
  check: <path d="M3 8.5l3.5 3.5L13 4.5" />,
  menu: <path d="M2 4h12M2 8h12M2 12h12" />,
  save: (
    <>
      <path d="M2.5 2.5h9l2 2v9h-11z" />
      <path d="M5 2.5v3.5h5V2.5M5 13.5V9.5h6v4" />
    </>
  ),
  edit: <path d="M2.5 13.5l.7-3 7-7 2.3 2.3-7 7z" />,
  desktop: (
    <>
      <rect x="1.5" y="3.5" width="13" height="9" />
      <path d="M1.5 10h13" />
    </>
  ),
} satisfies Record<string, ReactNode>;

export type IconName = keyof typeof GLYPHS;

export function Icon({ name, size = 14, className }: { name: IconName; size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.25"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={className}
      aria-hidden="true"
      style={{ flexShrink: 0 }}
    >
      {GLYPHS[name]}
    </svg>
  );
}
