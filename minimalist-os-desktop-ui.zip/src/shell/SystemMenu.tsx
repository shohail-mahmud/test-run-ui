import { OS_NAME, OS_VERSION } from "../os/brand";
import { services } from "../os/services";
import { updateSettings, useSettings } from "../os/settings";
import { MenuList, type MenuItem } from "../ui/controls";
import { wm } from "../wm/store";
import { TASKBAR_H } from "./Launcher";
import { launchApp } from "./launch";

/** Minimal system menu (bottom-right). Power actions go through the power service. */
export function SystemMenu({ onClose, onNotice }: { onClose: () => void; onNotice: (msg: string) => void }) {
  const s = useSettings();

  const power = (fn: () => Promise<{ ok: boolean; reason?: string }>) =>
    fn().then((r) => {
      if (!r.ok) onNotice(r.reason ?? "Not available.");
    });

  const items: MenuItem[] = [
    { label: `${OS_NAME} ${OS_VERSION}`, disabled: true },
    { separator: true, label: "" },
    { label: "Settings", icon: "settings", onClick: () => launchApp("settings") },
    { label: "Calendar", icon: "calendar", onClick: () => launchApp("calendar") },
    { label: s.theme === "light" ? "Switch to dark theme" : "Switch to light theme", icon: "appearance", onClick: () => updateSettings({ theme: s.theme === "light" ? "dark" : "light" }) },
    { label: "Hide / show all windows", icon: "desktop", hint: "Alt+H", onClick: () => wm.showDesktop() },
    { separator: true, label: "" },
    { label: "Restart", icon: "restart", onClick: () => power(() => services.power.restart()) },
    { label: "Shut down", icon: "power", onClick: () => power(() => services.power.shutdown()) },
  ];

  return (
    <>
      <div className="fixed left-0 right-0 top-0 z-[9000]" style={{ bottom: TASKBAR_H }} onPointerDown={onClose} />
      <div className="fixed right-0 z-[9001]" style={{ bottom: TASKBAR_H }}>
        <MenuList items={items} onDone={onClose} />
      </div>
    </>
  );
}
