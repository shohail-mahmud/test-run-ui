import { useMemo, useState } from "react";
import { APPS } from "../apps/registry";
import { Icon } from "../ui/Icon";
import { cn } from "../utils/cn";
import { launchApp } from "./launch";

export const TASKBAR_H = 28;

/** Application launcher: search, arrow keys, Enter. */
export function Launcher({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(0);

  const list = useMemo(() => {
    const n = q.trim().toLowerCase();
    return APPS.map((app, i) => ({ app, n: i + 1 })).filter(
      ({ app }) => !n || app.name.toLowerCase().includes(n) || app.description.toLowerCase().includes(n),
    );
  }, [q]);

  const run = (id: string) => {
    onClose();
    launchApp(id);
  };

  return (
    <>
      <div className="fixed left-0 right-0 top-0 z-[9000]" style={{ bottom: TASKBAR_H }} onPointerDown={onClose} />
      <div
        className="fixed left-0 z-[9001] w-60 bg-surface border border-line-strong border-l-0"
        style={{ bottom: TASKBAR_H }}
        role="dialog"
        aria-label="Launcher"
      >
        <div className="p-1 border-b border-line flex items-center gap-1.5 px-2">
          <Icon name="search" size={12} className="text-fg-dim" />
          <input
            autoFocus
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setIdx(0);
            }}
            onKeyDown={(e) => {
              if (e.key === "Escape") onClose();
              else if (e.key === "ArrowDown") {
                e.preventDefault();
                setIdx((i) => Math.min(list.length - 1, i + 1));
              } else if (e.key === "ArrowUp") {
                e.preventDefault();
                setIdx((i) => Math.max(0, i - 1));
              } else if (e.key === "Enter" && list[idx]) run(list[idx].app.id);
            }}
            placeholder="Search applications"
            aria-label="Search applications"
            className="flex-1 h-6 bg-transparent outline-none"
          />
        </div>
        <ul className="py-0.5">
          {list.map(({ app, n }, i) => (
            <li key={app.id}>
              <button
                onClick={() => run(app.id)}
                onMouseMove={() => setIdx(i)}
                className={cn("w-full h-8 px-2 flex items-center gap-2.5 text-left", i === idx && "bg-sel text-sel-fg")}
              >
                <Icon name={app.icon} size={16} />
                <span className="flex-1 min-w-0">
                  <span className="block leading-4">{app.name}</span>
                  <span className={cn("block text-[11px] leading-3 truncate", i === idx ? "opacity-70" : "text-fg-dim")}>{app.description}</span>
                </span>
                <span className={cn("text-[11px] font-mono", i === idx ? "opacity-70" : "text-fg-dim")}>Alt+{n}</span>
              </button>
            </li>
          ))}
          {list.length === 0 && <li className="px-2 py-2 text-fg-dim">No matches</li>}
        </ul>
      </div>
    </>
  );
}
