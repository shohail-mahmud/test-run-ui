import { useEffect, useRef, useState } from "react";
import { APPS } from "../apps/registry";
import { useSettings } from "../os/settings";
import { SHORTCUTS } from "../os/shortcuts";
import { Button } from "../ui/controls";
import { wm, useWM } from "../wm/store";
import { Launcher, TASKBAR_H } from "./Launcher";
import { launchApp, refocusWindow } from "./launch";
import { SystemMenu } from "./SystemMenu";
import { Taskbar } from "./Taskbar";
import { WindowLayer } from "./WindowLayer";

/** Pick a hint colour readable on the wallpaper. */
function hintColor(hex: string) {
  const n = parseInt(hex.slice(1), 16) || 0;
  const lum = (0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
  return lum > 0.55 ? "rgba(0,0,0,0.55)" : "rgba(255,255,255,0.6)";
}

export function Desktop() {
  const settings = useSettings();
  const { windows } = useWM();
  const [launcher, setLauncher] = useState(false);
  const [menu, setMenu] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const area = useRef<HTMLDivElement>(null);

  const closeLauncher = () => {
    setLauncher(false);
    refocusWindow();
  };
  const closeMenu = () => {
    setMenu(false);
    refocusWindow();
  };

  // Tell the window manager how big the desktop is.
  useEffect(() => {
    const measure = () => {
      const r = area.current?.getBoundingClientRect();
      if (r) wm.setDesktop(r.width, r.height);
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  // Global shortcuts (capture phase so they work while typing too).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && menu) return closeMenu();
      const sc = SHORTCUTS.find((s) => s.match(e));
      if (!sc) return;
      e.preventDefault();
      const st = wm.getState();
      switch (sc.id) {
        case "launcher":
          setMenu(false);
          setLauncher((v) => !v);
          break;
        case "next-window":
          wm.cycle(e.shiftKey ? -1 : 1);
          break;
        case "close-window":
          if (st.focusedId !== null) wm.close(st.focusedId);
          break;
        case "minimize-window":
          if (st.focusedId !== null) wm.minimize(st.focusedId);
          break;
        case "maximize-window":
          if (st.focusedId !== null) wm.toggleMaximize(st.focusedId);
          break;
        case "show-desktop":
          wm.showDesktop();
          break;
        case "launch-nth": {
          const app = APPS[Number(e.code.slice(5)) - 1];
          if (app) {
            setLauncher(false);
            launchApp(app.id);
          }
          break;
        }
      }
    };
    document.addEventListener("keydown", onKey, true);
    return () => document.removeEventListener("keydown", onKey, true);
  });

  // Theme is a data attribute; every colour comes from CSS variables.
  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme;
  }, [settings.theme]);

  return (
    <div className="fixed inset-0 overflow-hidden" style={{ background: settings.wallpaper }}>
      <div
        ref={area}
        className="absolute left-0 right-0 top-0 z-0"
        style={{ bottom: TASKBAR_H }}
        onPointerDown={(e) => {
          if (e.target === e.currentTarget) wm.blur();
        }}
      >
        {windows.length === 0 && (
          <div className="absolute right-3 bottom-2 text-[11px] pointer-events-none" style={{ color: hintColor(settings.wallpaper) }}>
            Alt+Space — launcher
          </div>
        )}
        <WindowLayer />
      </div>

      <Taskbar
        launcherOpen={launcher}
        menuOpen={menu}
        onToggleLauncher={() => {
          setMenu(false);
          if (launcher) closeLauncher();
          else setLauncher(true);
        }}
        onToggleMenu={() => {
          setLauncher(false);
          if (menu) closeMenu();
          else setMenu(true);
        }}
      />

      {launcher && <Launcher onClose={closeLauncher} />}
      {menu && <SystemMenu onClose={() => setMenu(false)} onNotice={setNotice} />}

      {notice && (
        <div className="fixed inset-0 z-[9700] grid place-items-center bg-black/30" style={{ bottom: TASKBAR_H }}>
          <div role="alertdialog" className="w-72 bg-surface border border-line-strong">
            <div className="h-6 px-2 flex items-center border-b border-line bg-surface-2 font-medium">System</div>
            <p className="p-3">{notice}</p>
            <div className="p-2 pt-0 flex justify-end">
              <Button
                primary
                autoFocus
                onClick={() => {
                  setNotice(null);
                  refocusWindow();
                }}
              >
                OK
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
