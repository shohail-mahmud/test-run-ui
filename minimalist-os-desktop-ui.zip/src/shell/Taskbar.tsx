import { getApp } from "../apps/registry";
import { OS_NAME } from "../os/brand";
import { formatDate, formatTime } from "../os/format";
import { useSettings } from "../os/settings";
import { useNow } from "../ui/hooks";
import { Icon } from "../ui/Icon";
import { cn } from "../utils/cn";
import { wm, useWM } from "../wm/store";
import { TASKBAR_H } from "./Launcher";
import { launchApp } from "./launch";

function Clock() {
  const s = useSettings();
  const now = useNow(1000);
  return (
    <button
      onClick={() => launchApp("calendar")}
      title={`${formatDate(now, "long")} — open Calendar`}
      className="h-6 px-2 flex items-center gap-2 hover:bg-surface-3 border border-transparent hover:border-line"
    >
      <span className="font-mono">{formatTime(now, s.clock24, s.showSeconds)}</span>
      <span className="text-fg-dim">{formatDate(now, s.dateFormat)}</span>
    </button>
  );
}

export function Taskbar({
  launcherOpen,
  menuOpen,
  onToggleLauncher,
  onToggleMenu,
}: {
  launcherOpen: boolean;
  menuOpen: boolean;
  onToggleLauncher: () => void;
  onToggleMenu: () => void;
}) {
  const { windows, focusedId } = useWM();
  const tasks = [...windows].sort((a, b) => a.id - b.id);

  return (
    <div
      className="absolute left-0 right-0 bottom-0 z-[9500] flex items-center gap-1 px-1 bg-surface-2 border-t border-line-strong"
      style={{ height: TASKBAR_H }}
      role="toolbar"
      aria-label="Taskbar"
    >
      <button
        onClick={onToggleLauncher}
        aria-expanded={launcherOpen}
        title="Launcher (Alt+Space)"
        className={cn(
          "h-6 px-2 flex items-center gap-1.5 border font-medium",
          launcherOpen ? "bg-sel text-sel-fg border-sel" : "border-transparent hover:bg-surface-3 hover:border-line",
        )}
      >
        <Icon name="logo" size={13} />
        {OS_NAME}
      </button>
      <span className="w-px h-4 bg-line mx-0.5" />

      <div className="flex-1 min-w-0 flex items-center gap-1 overflow-hidden">
        {tasks.map((w) => {
          const app = getApp(w.appId);
          const active = w.id === focusedId && !w.minimized;
          return (
            <button
              key={w.id}
              onClick={() => (active ? wm.minimize(w.id) : wm.focus(w.id))}
              title={w.title}
              className={cn(
                "h-6 min-w-0 w-36 shrink px-2 flex items-center gap-1.5 border text-left",
                active
                  ? "bg-surface-3 border-line-strong"
                  : w.minimized
                    ? "border-transparent text-fg-dim hover:bg-surface-3"
                    : "border-line hover:bg-surface-3",
              )}
            >
              {app && <Icon name={app.icon} size={12} />}
              <span className="truncate">{w.title}</span>
            </button>
          );
        })}
      </div>

      <Clock />
      <button
        onClick={onToggleMenu}
        aria-expanded={menuOpen}
        aria-label="System menu"
        title="System menu"
        className={cn(
          "h-6 w-6 grid place-items-center border",
          menuOpen ? "bg-sel text-sel-fg border-sel" : "border-transparent hover:bg-surface-3 hover:border-line",
        )}
      >
        <Icon name="menu" />
      </button>
    </div>
  );
}
