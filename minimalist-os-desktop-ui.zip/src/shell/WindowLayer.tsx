import { memo, useMemo } from "react";
import { getApp } from "../apps/registry";
import type { AppHost } from "../apps/types";
import { Icon } from "../ui/Icon";
import { wm, useWM, type Params, type WinState } from "../wm/store";
import { WindowFrame } from "../wm/WindowFrame";
import { launchApp } from "./launch";

const NO_PARAMS: Params = {};

/** Binds a window-manager entry to its application component. */
const WindowItem = memo(function WindowItem({ win, focused }: { win: WinState; focused: boolean }) {
  const app = getApp(win.appId);
  const host = useMemo<AppHost>(
    () => ({
      setTitle: (t) => wm.setTitle(win.id, t),
      close: () => wm.close(win.id),
      launch: launchApp,
    }),
    [win.id],
  );
  // Memoised so dragging/resizing a window does not re-render the app inside it.
  const body = useMemo(
    () => (app ? <app.Component windowId={win.id} focused={focused} params={win.params ?? NO_PARAMS} host={host} /> : null),
    [app, win.id, win.params, focused, host],
  );
  if (!app) return null;
  return (
    <WindowFrame win={win} focused={focused} icon={<Icon name={app.icon} size={12} />}>
      {body}
    </WindowFrame>
  );
});

export function WindowLayer() {
  const { windows, focusedId } = useWM();
  return (
    <>
      {windows.map((w) => (
        <WindowItem key={w.id} win={w} focused={w.id === focusedId} />
      ))}
    </>
  );
}
