import { getApp } from "../apps/registry";
import { wm } from "../wm/store";

/** The only place that turns an app manifest into a window. */
export function launchApp(appId: string, params?: Record<string, unknown>) {
  const app = getApp(appId);
  if (!app) return;
  const path = typeof params?.path === "string" ? params.path : null;
  const existing = wm
    .getState()
    .windows.find((w) => w.appId === appId && (app.singleton || (path !== null && w.params.path === path)));
  if (existing) {
    wm.focus(existing.id);
    return;
  }
  wm.open({
    appId,
    title: app.name,
    w: app.size.w,
    h: app.size.h,
    minW: app.minSize.w,
    minH: app.minSize.h,
    params,
  });
}

/** Return DOM focus to the focused window (after a popup closes). */
export function refocusWindow() {
  requestAnimationFrame(() => {
    const id = wm.getState().focusedId;
    if (id === null) return;
    const el = document.querySelector<HTMLElement>(`[data-win="${id}"]`);
    if (el && !el.contains(document.activeElement)) el.focus({ preventScroll: true });
  });
}
