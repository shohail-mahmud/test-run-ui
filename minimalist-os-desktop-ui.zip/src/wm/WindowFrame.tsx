import { memo, useEffect, useRef, type PointerEvent as RPointerEvent, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { Icon } from "../ui/Icon";
import { wm, type WinState } from "./store";

/**
 * Generic window chrome: title bar, controls, drag, 8-way resize.
 * It does not know what is inside; the shell passes the content as children.
 */

type Edge = "n" | "s" | "e" | "w" | "ne" | "nw" | "se" | "sw";

const HANDLES: { edge: Edge; cls: string; cursor: string }[] = [
  { edge: "n", cls: "top-[-3px] left-2 right-2 h-[6px]", cursor: "ns-resize" },
  { edge: "s", cls: "bottom-[-3px] left-2 right-2 h-[6px]", cursor: "ns-resize" },
  { edge: "w", cls: "left-[-3px] top-2 bottom-2 w-[6px]", cursor: "ew-resize" },
  { edge: "e", cls: "right-[-3px] top-2 bottom-2 w-[6px]", cursor: "ew-resize" },
  { edge: "nw", cls: "top-[-3px] left-[-3px] w-2.5 h-2.5", cursor: "nwse-resize" },
  { edge: "ne", cls: "top-[-3px] right-[-3px] w-2.5 h-2.5", cursor: "nesw-resize" },
  { edge: "sw", cls: "bottom-[-3px] left-[-3px] w-2.5 h-2.5", cursor: "nesw-resize" },
  { edge: "se", cls: "bottom-[-3px] right-[-3px] w-2.5 h-2.5", cursor: "nwse-resize" },
];

function track(e: RPointerEvent, cursor: string, onMove: (dx: number, dy: number) => void) {
  e.preventDefault();
  const sx = e.clientX;
  const sy = e.clientY;
  const mv = (ev: PointerEvent) => onMove(ev.clientX - sx, ev.clientY - sy);
  const up = () => {
    window.removeEventListener("pointermove", mv);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    document.body.style.userSelect = "";
    document.body.style.cursor = "";
  };
  window.addEventListener("pointermove", mv);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
  document.body.style.userSelect = "none";
  document.body.style.cursor = cursor;
}

interface Props {
  win: WinState;
  focused: boolean;
  icon: ReactNode;
  children: ReactNode;
}

export const WindowFrame = memo(function WindowFrame({ win, focused, icon, children }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  // Keep DOM focus inside the focused window so keyboard input lands there.
  useEffect(() => {
    const el = ref.current;
    if (focused && el && !el.contains(document.activeElement)) el.focus({ preventScroll: true });
  }, [focused]);

  const startDrag = (e: RPointerEvent) => {
    if (e.button !== 0 || win.maximized) return;
    const { x, y, id } = win;
    track(e, "default", (dx, dy) => wm.move(id, x + dx, y + dy));
  };

  const startResize = (e: RPointerEvent, edge: Edge, cursor: string) => {
    if (e.button !== 0) return;
    const { x: ox, y: oy, w: ow, h: oh, minW, minH, id } = win;
    track(e, cursor, (dx, dy) => {
      let x = ox;
      let y = oy;
      let w = ow;
      let h = oh;
      if (edge.includes("e")) w = Math.max(minW, ow + dx);
      if (edge.includes("s")) h = Math.max(minH, oh + dy);
      if (edge.includes("w")) {
        w = Math.max(minW, ow - dx);
        x = ox + (ow - w);
      }
      if (edge.includes("n")) {
        h = Math.max(minH, oh - dy);
        y = oy + (oh - h);
        if (y < 0) {
          h += y;
          y = 0;
        }
      }
      wm.setRect(id, { x, y, w, h });
    });
  };

  const style = win.maximized
    ? { left: 0, top: 0, right: 0, bottom: 0, zIndex: win.z }
    : { left: win.x, top: win.y, width: win.w, height: win.h, zIndex: win.z };

  return (
    <div
      ref={ref}
      tabIndex={-1}
      data-win={win.id}
      role="dialog"
      aria-label={win.title}
      onPointerDownCapture={() => wm.focus(win.id)}
      style={style}
      className={cn(
        "absolute flex flex-col bg-surface border outline-none",
        focused ? "border-fg" : "border-line-strong",
        win.minimized && "hidden",
      )}
    >
      <div
        onPointerDown={startDrag}
        onDoubleClick={() => wm.toggleMaximize(win.id)}
        className={cn(
          "h-6 shrink-0 flex items-center border-b select-none",
          focused ? "bg-sel text-sel-fg border-fg" : "bg-surface-2 text-fg-dim border-line",
        )}
      >
        <span className="pl-2 pr-1.5 flex items-center">{icon}</span>
        <span className="flex-1 truncate text-xs">{win.title}</span>
        <div className="flex h-full" onPointerDown={(e) => e.stopPropagation()} onDoubleClick={(e) => e.stopPropagation()}>
          <button
            aria-label="Minimise"
            title="Minimise (Alt+M)"
            onClick={() => wm.minimize(win.id)}
            className="w-7 grid place-items-center hover:bg-black/20"
          >
            <Icon name="minimize" size={12} />
          </button>
          <button
            aria-label={win.maximized ? "Restore" : "Maximise"}
            title={win.maximized ? "Restore (Alt+Enter)" : "Maximise (Alt+Enter)"}
            onClick={() => wm.toggleMaximize(win.id)}
            className="w-7 grid place-items-center hover:bg-black/20"
          >
            <Icon name={win.maximized ? "restore" : "maximize"} size={12} />
          </button>
          <button
            aria-label="Close"
            title="Close (Alt+W)"
            onClick={() => wm.close(win.id)}
            className="w-7 grid place-items-center hover:bg-danger hover:text-white"
          >
            <Icon name="close" size={12} />
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0 relative overflow-hidden">{children}</div>

      {!win.maximized &&
        HANDLES.map((h) => (
          <div
            key={h.edge}
            onPointerDown={(e) => startResize(e, h.edge, h.cursor)}
            style={{ cursor: h.cursor }}
            className={cn("absolute z-10", h.cls)}
          />
        ))}
    </div>
  );
});
