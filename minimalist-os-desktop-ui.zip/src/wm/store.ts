/**
 * Window manager state. Pure state + actions: no knowledge of apps, the
 * taskbar or React components (only a thin hook at the bottom). Every update
 * is immutable so only the changed window re-renders.
 */
import { useSyncExternalStore } from "react";

export type Params = Record<string, unknown>;

export interface WinState {
  id: number;
  appId: string;
  title: string;
  x: number;
  y: number;
  w: number;
  h: number;
  minW: number;
  minH: number;
  minimized: boolean;
  maximized: boolean;
  z: number;
  params: Params;
}

export interface OpenSpec {
  appId: string;
  title: string;
  w: number;
  h: number;
  minW: number;
  minH: number;
  params?: Params;
}

interface WMState {
  windows: WinState[];
  focusedId: number | null;
  nextId: number;
  nextZ: number;
  desktop: { w: number; h: number };
}

export const TITLEBAR_H = 24;
const EMPTY: Params = {};

let state: WMState = {
  windows: [],
  focusedId: null,
  nextId: 1,
  nextZ: 1,
  desktop: { w: 1280, h: 720 },
};
const listeners = new Set<() => void>();

function set(next: WMState) {
  state = next;
  listeners.forEach((l) => l());
}

function topVisible(windows: WinState[], exclude?: number): number | null {
  let best: WinState | null = null;
  for (const w of windows) {
    if (w.minimized || w.id === exclude) continue;
    if (!best || w.z > best.z) best = w;
  }
  return best ? best.id : null;
}

function patch(id: number, fn: (w: WinState) => WinState) {
  set({ ...state, windows: state.windows.map((w) => (w.id === id ? fn(w) : w)) });
}

export const wm = {
  getState: () => state,

  subscribe(l: () => void) {
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  },

  open(spec: OpenSpec): number {
    const { desktop } = state;
    const w = Math.min(spec.w, desktop.w);
    const h = Math.min(spec.h, desktop.h);
    const n = state.windows.length % 8;
    const x = Math.max(0, Math.min(48 + n * 26, desktop.w - w));
    const y = Math.max(0, Math.min(32 + n * 26, desktop.h - h));
    const win: WinState = {
      id: state.nextId,
      appId: spec.appId,
      title: spec.title,
      x,
      y,
      w,
      h,
      minW: spec.minW,
      minH: spec.minH,
      minimized: false,
      maximized: false,
      z: state.nextZ,
      params: spec.params ?? EMPTY,
    };
    set({
      ...state,
      windows: [...state.windows, win],
      focusedId: win.id,
      nextId: state.nextId + 1,
      nextZ: state.nextZ + 1,
    });
    return win.id;
  },

  close(id: number) {
    const windows = state.windows.filter((w) => w.id !== id);
    set({
      ...state,
      windows,
      focusedId: state.focusedId === id ? topVisible(windows) : state.focusedId,
    });
  },

  /** Raise, un-minimise and focus. */
  focus(id: number) {
    const win = state.windows.find((w) => w.id === id);
    if (!win) return;
    if (state.focusedId === id && !win.minimized) return;
    set({
      ...state,
      windows: state.windows.map((w) =>
        w.id === id ? { ...w, minimized: false, z: state.nextZ } : w,
      ),
      focusedId: id,
      nextZ: state.nextZ + 1,
    });
  },

  blur() {
    if (state.focusedId !== null) set({ ...state, focusedId: null });
  },

  minimize(id: number) {
    const windows = state.windows.map((w) => (w.id === id ? { ...w, minimized: true } : w));
    set({
      ...state,
      windows,
      focusedId: state.focusedId === id ? topVisible(windows) : state.focusedId,
    });
  },

  toggleMaximize(id: number) {
    patch(id, (w) => ({ ...w, maximized: !w.maximized }));
  },

  move(id: number, x: number, y: number) {
    const { desktop } = state;
    patch(id, (w) => ({
      ...w,
      x: Math.round(Math.max(-(w.w - 80), Math.min(x, desktop.w - 80))),
      y: Math.round(Math.max(0, Math.min(y, desktop.h - TITLEBAR_H))),
    }));
  },

  setRect(id: number, r: { x: number; y: number; w: number; h: number }) {
    patch(id, (w) => ({ ...w, x: r.x, y: r.y, w: r.w, h: r.h }));
  },

  setTitle(id: number, title: string) {
    patch(id, (w) => (w.title === title ? w : { ...w, title }));
  },

  /** Cycle through windows in taskbar order. */
  cycle(dir: 1 | -1) {
    const list = [...state.windows].sort((a, b) => a.id - b.id);
    if (list.length === 0) return;
    const i = list.findIndex((w) => w.id === state.focusedId);
    const next = list[(i + dir + list.length * 2) % list.length];
    wm.focus(next.id);
  },

  /** Minimise everything, or restore if everything is already hidden. */
  showDesktop() {
    const anyVisible = state.windows.some((w) => !w.minimized);
    if (anyVisible) {
      set({
        ...state,
        windows: state.windows.map((w) => ({ ...w, minimized: true })),
        focusedId: null,
      });
    } else if (state.windows.length) {
      const sorted = [...state.windows].sort((a, b) => b.z - a.z);
      set({
        ...state,
        windows: state.windows.map((w) => ({ ...w, minimized: false })),
        focusedId: sorted[0].id,
      });
    }
  },

  setDesktop(w: number, h: number) {
    if (state.desktop.w === w && state.desktop.h === h) return;
    set({ ...state, desktop: { w, h } });
  },
};

export function useWM(): WMState {
  return useSyncExternalStore(wm.subscribe, wm.getState);
}
