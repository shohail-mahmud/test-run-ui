/**
 * System settings store. State is held in memory and persisted as JSON
 * through the FileSystem service (not browser storage), so it moves to the
 * real filesystem as soon as the real backend is registered.
 */
import { useSyncExternalStore } from "react";
import { CONFIG_DIR } from "./brand";
import type { DateFormat } from "./format";
import { services } from "./services";

export interface Settings {
  theme: "light" | "dark";
  wallpaper: string; // solid colour, #rrggbb
  clock24: boolean;
  showSeconds: boolean;
  dateFormat: DateFormat;
  weekStart: 0 | 1; // 0 = Sunday, 1 = Monday
  keyboardLayout: string;
  keyRepeatDelayMs: number;
  keyRepeatRate: number;
}

export const DEFAULT_SETTINGS: Settings = {
  theme: "light",
  wallpaper: "#3f4446",
  clock24: true,
  showSeconds: false,
  dateFormat: "short",
  weekStart: 1,
  keyboardLayout: "us",
  keyRepeatDelayMs: 500,
  keyRepeatRate: 25,
};

export const SETTINGS_PATH = `${CONFIG_DIR}/settings.json`;

let state: Settings = DEFAULT_SETTINGS;
const listeners = new Set<() => void>();
let saveTimer: ReturnType<typeof setTimeout> | undefined;

function emit() {
  listeners.forEach((l) => l());
}

async function save() {
  try {
    await services.fs.mkdir(CONFIG_DIR, { recursive: true });
    await services.fs.writeText(SETTINGS_PATH, JSON.stringify(state, null, 2));
  } catch {
    /* settings stay in memory if the backend refuses */
  }
}

export async function loadSettings() {
  try {
    if (await services.fs.exists(SETTINGS_PATH)) {
      const raw = JSON.parse(await services.fs.readText(SETTINGS_PATH));
      state = { ...DEFAULT_SETTINGS, ...raw };
      emit();
    }
  } catch {
    /* fall back to defaults */
  }
}

export function updateSettings(patch: Partial<Settings>) {
  state = { ...state, ...patch };
  emit();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(save, 300);
}

export function getSettings() {
  return state;
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

export function useSettings(): Settings {
  return useSyncExternalStore(subscribe, getSettings);
}
