/**
 * FileSystem service contract.
 *
 * This is the boundary between the UI and the OS. Applications only ever talk
 * to this interface (via `services.fs`). To connect the real kernel, write an
 * implementation that forwards each call to the OS filesystem API (syscalls,
 * IPC, a local socket - whatever the runtime provides) and register it in
 * `services/index.ts`. No app needs to change.
 *
 * Every method is async because the real implementation will be IPC/IO.
 * Paths are absolute, POSIX-style, "/"-separated.
 */

export type FsKind = "file" | "dir";

export interface FsEntry {
  path: string;
  name: string;
  kind: FsKind;
  /** Size in bytes. 0 for directories. */
  size: number;
  /** Unix epoch milliseconds. */
  created: number;
  modified: number;
}

export type FsErrorCode =
  | "ENOENT"
  | "EEXIST"
  | "ENOTDIR"
  | "EISDIR"
  | "EINVAL"
  | "EACCES";

export class FsError extends Error {
  readonly code: FsErrorCode;
  constructor(code: FsErrorCode, message?: string) {
    super(message ?? code);
    this.name = "FsError";
    this.code = code;
  }
}

export interface FileSystem {
  /** Human-readable backend id, shown in the UI so it is never ambiguous. */
  readonly backend: string;

  list(path: string): Promise<FsEntry[]>;
  stat(path: string): Promise<FsEntry>;
  exists(path: string): Promise<boolean>;

  readText(path: string): Promise<string>;
  writeText(path: string, data: string): Promise<void>;

  mkdir(path: string, opts?: { recursive?: boolean }): Promise<void>;
  /** Removes a file or a directory tree. */
  remove(path: string): Promise<void>;
  /** Renames within the same directory. Returns the new path. */
  rename(path: string, newName: string): Promise<string>;
  /** `dest` is the full destination path, not a directory. Fails with EEXIST. */
  copy(src: string, dest: string): Promise<string>;
  move(src: string, dest: string): Promise<string>;

  /** Notified after any change. Real backends can map this to inotify-like events. */
  subscribe(listener: () => void): () => void;
}

export function describeFsError(e: unknown): string {
  if (e instanceof FsError) return e.message;
  return e instanceof Error ? e.message : String(e);
}
