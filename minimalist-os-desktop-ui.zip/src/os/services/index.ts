/**
 * Service registry - the ONLY file that decides which backend is in use.
 *
 * To integrate the real OS, implement the interfaces in `./fs` and `./system`
 * and swap the mock instances below. Apps import `services` and never import
 * anything from `./mock`.
 */
import { MemFs } from "./mock/memfs";
import { MockDisplay, MockPower, MockSystem } from "./mock/system";
import type { Services } from "./system";

export const services: Services = {
  fs: new MemFs(),
  system: new MockSystem(),
  display: new MockDisplay(),
  power: new MockPower(),
};

export type { FileSystem, FsEntry } from "./fs";
export { FsError, describeFsError } from "./fs";
