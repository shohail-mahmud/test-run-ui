/**
 * System-level service contracts: hardware/system information, display
 * and power. Fields that the backend cannot provide are `null` - the UI
 * shows "Not available" rather than inventing numbers.
 */

export interface SystemInfo {
  hostname: string | null;
  osName: string;
  osVersion: string;
  kernel: string | null;
  arch: string | null;
  cpu: string | null;
  memoryTotal: number | null;
  memoryUsed: number | null;
  storageTotal: number | null;
  storageUsed: number | null;
  uptimeSec: number | null;
}

export interface SystemService {
  readonly backend: string;
  info(): Promise<SystemInfo>;
}

export interface DisplayMode {
  width: number;
  height: number;
  refreshHz: number;
}

export interface ActionResult {
  ok: boolean;
  reason?: string;
}

export interface DisplayService {
  readonly backend: string;
  listModes(): Promise<DisplayMode[]>;
  /** null when the backend cannot tell. */
  currentMode(): Promise<DisplayMode | null>;
  setMode(mode: DisplayMode): Promise<ActionResult>;
}

export interface PowerService {
  readonly backend: string;
  shutdown(): Promise<ActionResult>;
  restart(): Promise<ActionResult>;
}

export interface Services {
  fs: import("./fs").FileSystem;
  system: SystemService;
  display: DisplayService;
  power: PowerService;
}
