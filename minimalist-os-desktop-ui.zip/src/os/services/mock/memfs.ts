/**
 * DEVELOPMENT-ONLY filesystem backend. Lives purely in memory and is lost on
 * reload. It exists so the UI can be built and exercised before the kernel
 * filesystem exists. It is NOT the OS filesystem - replace it by implementing
 * `FileSystem` against the real API (see services/index.ts).
 */
import { basename, dirname, isInside, normalize } from "../../path";
import { FsError, type FileSystem, type FsEntry } from "../fs";

interface MNode {
  kind: "file" | "dir";
  data: string;
  created: number;
  modified: number;
}

const enc = new TextEncoder();

export class MemFs implements FileSystem {
  readonly backend = "mock: in-memory (development only)";
  private nodes = new Map<string, MNode>();
  private listeners = new Set<() => void>();

  constructor() {
    const t = Date.now();
    this.nodes.set("/", { kind: "dir", data: "", created: t, modified: t });
    this.seed();
  }

  private seed() {
    const dirs = [
      "/home",
      "/home/user",
      "/home/user/Documents",
      "/home/user/Documents/Projects",
      "/home/user/Downloads",
      "/home/user/Pictures",
      "/tmp",
      "/etc",
    ];
    dirs.forEach((d, i) => this.put(d, "dir", "", 86_400_000 * (30 - i)));
    this.put(
      "/home/user/Documents/welcome.txt",
      "file",
      "Welcome.\n\nThis file lives in a mock in-memory filesystem used for UI development.\nThe file manager talks to the FileSystem interface in src/os/services/fs.ts.\n",
      3_600_000 * 20,
    );
    this.put(
      "/home/user/Documents/notes.txt",
      "file",
      "- connect FileSystem service to the kernel\n- port the window manager to the display server\n",
      3_600_000 * 5,
    );
    this.put(
      "/home/user/Documents/Projects/todo.txt",
      "file",
      "1. boot\n2. draw\n3. ship\n",
      3_600_000 * 2,
    );
    this.put(
      "/etc/os-release",
      "file",
      'NAME="Tern"\nVERSION="0.1.0-ui-prototype"\n',
      86_400_000 * 10,
    );
  }

  private put(path: string, kind: "file" | "dir", data: string, ageMs: number) {
    const t = Date.now() - ageMs;
    this.nodes.set(path, { kind, data, created: t, modified: t });
  }

  private emit() {
    this.listeners.forEach((l) => l());
  }

  private get(path: string): MNode {
    const n = this.nodes.get(normalize(path));
    if (!n) throw new FsError("ENOENT", `No such file or folder: ${path}`);
    return n;
  }

  private entry(path: string, n: MNode): FsEntry {
    const p = normalize(path);
    return {
      path: p,
      name: basename(p),
      kind: n.kind,
      size: n.kind === "file" ? enc.encode(n.data).length : 0,
      created: n.created,
      modified: n.modified,
    };
  }

  private requireDirParent(path: string) {
    const parent = this.nodes.get(dirname(path));
    if (!parent) throw new FsError("ENOENT", "Destination folder does not exist");
    if (parent.kind !== "dir") throw new FsError("ENOTDIR", "Destination is not a folder");
  }

  private transfer(src: string, dest: string, copy: boolean): string {
    src = normalize(src);
    dest = normalize(dest);
    const node = this.get(src);
    if (src === "/") throw new FsError("EINVAL", "Cannot modify the root folder");
    if (node.kind === "dir" && (dest === src || isInside(src, dest)))
      throw new FsError("EINVAL", "Cannot place a folder inside itself");
    this.requireDirParent(dest);
    if (this.nodes.has(dest)) throw new FsError("EEXIST", `"${basename(dest)}" already exists`);
    const now = Date.now();
    const keys = [...this.nodes.keys()].filter((k) => k === src || isInside(src, k));
    for (const k of keys) {
      const n = this.nodes.get(k)!;
      const nk = dest + k.slice(src.length);
      this.nodes.set(nk, copy ? { ...n, created: now, modified: now } : n);
      if (!copy) this.nodes.delete(k);
    }
    this.emit();
    return dest;
  }

  async list(path: string): Promise<FsEntry[]> {
    const p = normalize(path);
    const n = this.get(p);
    if (n.kind !== "dir") throw new FsError("ENOTDIR", `Not a folder: ${path}`);
    const out: FsEntry[] = [];
    for (const [k, v] of this.nodes) {
      if (k !== "/" && k !== p && dirname(k) === p) out.push(this.entry(k, v));
    }
    return out;
  }

  async stat(path: string) {
    return this.entry(path, this.get(path));
  }

  async exists(path: string) {
    return this.nodes.has(normalize(path));
  }

  async readText(path: string) {
    const n = this.get(path);
    if (n.kind !== "file") throw new FsError("EISDIR", `Is a folder: ${path}`);
    return n.data;
  }

  async writeText(path: string, data: string) {
    const p = normalize(path);
    const existing = this.nodes.get(p);
    if (existing?.kind === "dir") throw new FsError("EISDIR", `Is a folder: ${path}`);
    if (!existing) this.requireDirParent(p);
    const now = Date.now();
    this.nodes.set(p, { kind: "file", data, created: existing?.created ?? now, modified: now });
    this.emit();
  }

  async mkdir(path: string, opts?: { recursive?: boolean }) {
    const p = normalize(path);
    if (opts?.recursive) {
      let cur = "";
      for (const seg of p.split("/").filter(Boolean)) {
        cur += "/" + seg;
        const ex = this.nodes.get(cur);
        if (ex && ex.kind !== "dir") throw new FsError("ENOTDIR", `Not a folder: ${cur}`);
        if (!ex) {
          const t = Date.now();
          this.nodes.set(cur, { kind: "dir", data: "", created: t, modified: t });
        }
      }
      this.emit();
      return;
    }
    if (this.nodes.has(p)) throw new FsError("EEXIST", `"${basename(p)}" already exists`);
    this.requireDirParent(p);
    const t = Date.now();
    this.nodes.set(p, { kind: "dir", data: "", created: t, modified: t });
    this.emit();
  }

  async remove(path: string) {
    const p = normalize(path);
    if (p === "/") throw new FsError("EACCES", "Cannot remove the root folder");
    this.get(p);
    for (const k of [...this.nodes.keys()]) {
      if (k === p || isInside(p, k)) this.nodes.delete(k);
    }
    this.emit();
  }

  async rename(path: string, newName: string) {
    const name = newName.trim();
    if (!name || name.includes("/") || name === "." || name === "..")
      throw new FsError("EINVAL", "Invalid name");
    return this.transfer(path, normalize(dirname(path) + "/" + name), false);
  }

  async copy(src: string, dest: string) {
    return this.transfer(src, dest, true);
  }

  async move(src: string, dest: string) {
    return this.transfer(src, dest, false);
  }

  subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }
}
