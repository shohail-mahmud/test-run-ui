/**
 * DEVELOPMENT-ONLY system/display/power backends. They report only what the
 * UI layer genuinely knows. Everything else is `null` ("Not available") and
 * actions that need a real backend return `{ ok: false }` with a reason.
 */
import { OS_CHANNEL, OS_NAME, OS_VERSION } from "../../brand";
import type {
  ActionResult,
  DisplayMode,
  DisplayService,
  PowerService,
  SystemInfo,
  SystemService,
} from "../system";

export class MockSystem implements SystemService {
  readonly backend = "none (UI prototype)";
  async info(): Promise<SystemInfo> {
    return {
      hostname: null,
      osName: OS_NAME,
      osVersion: `${OS_VERSION}-${OS_CHANNEL}`,
      kernel: null,
      arch: null,
      cpu: null,
      memoryTotal: null,
      memoryUsed: null,
      storageTotal: null,
      storageUsed: null,
      uptimeSec: null,
    };
  }
}

const MODES: DisplayMode[] = [
  { width: 640, height: 480, refreshHz: 60 },
  { width: 800, height: 600, refreshHz: 60 },
  { width: 1024, height: 768, refreshHz: 60 },
  { width: 1280, height: 720, refreshHz: 60 },
  { width: 1366, height: 768, refreshHz: 60 },
  { width: 1920, height: 1080, refreshHz: 60 },
];

export class MockDisplay implements DisplayService {
  readonly backend = "none (no display driver connected)";
  async listModes() {
    return MODES;
  }
  async currentMode() {
    return null;
  }
  async setMode(): Promise<ActionResult> {
    return { ok: false, reason: "No display driver is connected. The mode was not changed." };
  }
}

export class MockPower implements PowerService {
  readonly backend = "none (no power management connected)";
  async shutdown(): Promise<ActionResult> {
    return { ok: false, reason: "Power management is not connected." };
  }
  async restart(): Promise<ActionResult> {
    return { ok: false, reason: "Power management is not connected." };
  }
}
