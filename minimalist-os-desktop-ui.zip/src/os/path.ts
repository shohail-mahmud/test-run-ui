/**
 * POSIX-style path helpers. Pure functions, no platform dependency, so this
 * file can be reused as-is by any runtime that talks to the OS filesystem.
 */

export function normalize(p: string): string {
  const parts: string[] = [];
  for (const seg of p.split("/")) {
    if (!seg || seg === ".") continue;
    if (seg === "..") {
      parts.pop();
      continue;
    }
    parts.push(seg);
  }
  return "/" + parts.join("/");
}

export function join(...segs: string[]): string {
  return normalize(segs.join("/"));
}

export function dirname(p: string): string {
  const n = normalize(p);
  if (n === "/") return "/";
  const i = n.lastIndexOf("/");
  return i <= 0 ? "/" : n.slice(0, i);
}

export function basename(p: string): string {
  const n = normalize(p);
  return n === "/" ? "/" : n.slice(n.lastIndexOf("/") + 1);
}

export function extname(p: string): string {
  const b = basename(p);
  const i = b.lastIndexOf(".");
  return i > 0 ? b.slice(i + 1).toLowerCase() : "";
}

/** True when `child` is strictly inside `parent`. */
export function isInside(parent: string, child: string): boolean {
  const p = normalize(parent);
  const c = normalize(child);
  if (p === c) return false;
  return c.startsWith(p === "/" ? "/" : p + "/");
}

/** "name.txt" -> "name copy.txt" -> "name copy 2.txt" ... */
export function uniqueName(
  name: string,
  existing: Set<string>,
  suffix = " copy",
): string {
  if (!existing.has(name)) return name;
  const dot = name.lastIndexOf(".");
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : "";
  let candidate = `${stem}${suffix}${ext}`;
  for (let i = 2; existing.has(candidate); i++) {
    candidate = `${stem}${suffix} ${i}${ext}`;
  }
  return candidate;
}
