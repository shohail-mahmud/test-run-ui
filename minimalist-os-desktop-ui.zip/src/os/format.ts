/**
 * Date/time/size formatting. Deliberately does not use Intl so that the same
 * logic can run on a minimal runtime with no locale database.
 */

export const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
export const MONTHS_SHORT = MONTHS.map((m) => m.slice(0, 3));
export const DAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
export const DAYS_LONG = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

export type DateFormat = "short" | "long" | "iso" | "dmy" | "mdy";

export const pad = (n: number, len = 2) => String(n).padStart(len, "0");

export function formatTime(d: Date, clock24: boolean, seconds: boolean) {
  const h = d.getHours();
  const tail = `:${pad(d.getMinutes())}${seconds ? ":" + pad(d.getSeconds()) : ""}`;
  if (clock24) return `${pad(h)}${tail}`;
  return `${h % 12 || 12}${tail} ${h >= 12 ? "PM" : "AM"}`;
}

export function formatDate(d: Date, f: DateFormat) {
  const day = pad(d.getDate());
  const mon = pad(d.getMonth() + 1);
  switch (f) {
    case "iso":
      return `${d.getFullYear()}-${mon}-${day}`;
    case "dmy":
      return `${day}/${mon}/${d.getFullYear()}`;
    case "mdy":
      return `${mon}/${day}/${d.getFullYear()}`;
    case "long":
      return `${DAYS_LONG[d.getDay()]}, ${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
    default:
      return `${DAYS_SHORT[d.getDay()]} ${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}`;
  }
}

/** "YYYY-MM-DD" key for a date, used for calendar events. */
export const ymd = (d: Date) =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export function formatDateTime(ms: number) {
  const d = new Date(ms);
  return `${ymd(d)} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let v = bytes / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v < 10 ? v.toFixed(1) : Math.round(v)} ${units[i]}`;
}
