/** Single place for the OS identity. Rename the OS here. */
export const OS_NAME = "Tern";
export const OS_VERSION = "0.1.0";
export const OS_CHANNEL = "ui-prototype";

/** Conventional locations. Align these with the real OS filesystem layout. */
export const HOME = "/home/user";
export const CONFIG_DIR = `${HOME}/.config`;
export const DATA_DIR = `${HOME}/.local/share`;
