/**
 * Global shortcut table. The shell binds actions by `id`; Settings > Keyboard
 * renders this same table, so docs and behaviour cannot drift apart.
 * Matching uses `event.code` so it is layout independent.
 */
export interface Shortcut {
  id: string;
  keys: string;
  description: string;
  match: (e: KeyboardEvent) => boolean;
}

const alt = (e: KeyboardEvent, code: string) =>
  e.altKey && !e.ctrlKey && !e.metaKey && e.code === code;

export const SHORTCUTS: Shortcut[] = [
  { id: "launcher", keys: "Alt+Space", description: "Open launcher", match: (e) => alt(e, "Space") },
  {
    id: "next-window",
    keys: "Alt+Tab / Alt+N",
    description: "Next window (Shift: previous)",
    match: (e) => alt(e, "Tab") || alt(e, "KeyN"),
  },
  { id: "close-window", keys: "Alt+W", description: "Close window", match: (e) => alt(e, "KeyW") },
  { id: "minimize-window", keys: "Alt+M", description: "Minimise window", match: (e) => alt(e, "KeyM") },
  { id: "maximize-window", keys: "Alt+Enter", description: "Maximise / restore window", match: (e) => alt(e, "Enter") },
  { id: "show-desktop", keys: "Alt+H", description: "Hide / show all windows", match: (e) => alt(e, "KeyH") },
  {
    id: "launch-nth",
    keys: "Alt+1 … Alt+9",
    description: "Launch application by launcher position",
    match: (e) => e.altKey && !e.ctrlKey && !e.metaKey && /^Digit[1-9]$/.test(e.code),
  },
];
