# Open-source review

## Status of this codebase

**No third-party application source has been copied into this repository.**
All apps and the window manager were written for this project. I did not port existing
code in this pass because the realistic candidates below are written in C/C++ for
other toolkits (GTK/Qt/X11) and would be a rewrite for your runtime anyway; copying
them into a TypeScript UI would add licence obligations without saving work.

Runtime/build dependencies actually used: React (MIT), clsx (MIT), tailwind-merge (MIT);
build-time only: Vite (MIT), Tailwind CSS (MIT), TypeScript (Apache-2.0).

## Candidates for the real OS (licences are from memory — **verify each repo's LICENSE file and the exact version before using any code**)

| Need | Candidate | Licence (verify) | Notes |
| ---- | --------- | ---------------- | ----- |
| Native UI toolkit / rendering | LVGL | MIT | Small, embedded-friendly, framebuffer backends. Strong fit for a 10–50 MB OS. |
| Minimal immediate-mode UI | microui (rxi) | MIT | ~1k lines of C. Good for tools, too bare for a full desktop. |
| Immediate-mode UI | Nuklear | MIT / public domain | Single header. |
| Image decoding (Pictures) | stb_image | public domain / MIT | Single header. |
| Fonts | Spleen, Terminus | BSD-2 / SIL OFL | Bitmap fonts, tiny; OFL has redistribution conditions. |
| Structured storage (calendar, settings) | SQLite | public domain | Heavier than JSON; consider only if events get large. |
| Calendar interchange | iCalendar (RFC 5545) | open standard | Store events as `.ics` for compatibility. `libical` is MPL-2.0 / LGPL-2.1 — a weak-copyleft obligation. |
| Scripting for apps | Lua | MIT | ~250 KB; a candidate application runtime. |
| libc | musl | MIT | Small, static-link friendly. |
| Reference designs for apps | SerenityOS apps (Calculator, FileManager, Calendar) | BSD-2-Clause | Permissive and C++; best *reference* for behaviour and structure; depends on Serenity's LibGUI, so a port means reimplementing the UI layer. |
| Reference designs | Haiku (Tracker, etc.) | MIT | Same caveat: tied to the Haiku API. |

## Avoid unless your OS is itself GPL

GNOME Calculator, galculator, PCManFM, Thunar, BusyBox and most classic Linux desktop
apps are GPL/LGPL. They are fine as *behavioural* inspiration but copying their code makes the
combined work GPL-bound. They also drag in GTK/Qt/GLib, which is the opposite of your size target.

## Suggested path

1. Keep these TypeScript apps as the executable spec of behaviour.
2. When the display and input subsystems exist, evaluate LVGL as the native renderer and re-implement the
   shell against the same service interfaces (`src/os/services`).
3. For anything ported, record source, version, licence and copyright notice in this file.
