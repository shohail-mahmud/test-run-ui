# Tern UI — architecture

This repository is the **UI layer** of an operating system: desktop shell, window
manager and built-in apps. It is currently developed in a browser engine only as a
convenient rendering host. There is **no kernel here and nothing in this build is
bootable**. Anything that stands in for the OS is a clearly labelled mock.

## Layers

```
src/
  os/            The OS-facing boundary (no React except small hooks)
    services/      Interfaces: FileSystem, SystemService, DisplayService, PowerService
      mock/        DEV-ONLY backends (in-memory fs, "not available" system/power/display)
      index.ts     The single file that chooses backends  <-- swap mocks for real ones here
    settings.ts    Settings store, persisted through services.fs
    shortcuts.ts   Global shortcut table (also rendered in Settings > Keyboard)
    path.ts, format.ts, brand.ts   Pure helpers / constants
  wm/            Window manager. store.ts = pure state + actions. WindowFrame = generic chrome.
  shell/         Desktop, taskbar, launcher, system menu. Binds wm <-> apps.
  apps/          One folder per app. Manifest + component. Registry in registry.ts.
  ui/            Tiny shared widgets (Icon, Button, Modal, Menu) and hooks.
```

Dependency direction: `shell → wm, apps, os` · `apps → os, ui` · `wm → (nothing)` · `os → (nothing)`.
Apps never import the window manager or the shell; they receive a small `host`
object (`setTitle`, `close`, `launch`). That keeps them portable to a future app runtime.

## Connecting the real OS

| UI piece              | Contract                      | Replace by                                   |
| --------------------- | ----------------------------- | -------------------------------------------- |
| Files, Text, Calendar | `FileSystem` (`os/services/fs.ts`) | Class forwarding to the OS filesystem API |
| Settings > System     | `SystemService`               | Kernel/system info query                     |
| Settings > Display    | `DisplayService`              | Display subsystem (mode list + set mode)     |
| System menu power     | `PowerService`                | Power management                             |
| Settings persistence  | `FileSystem` (`~/.config/settings.json`) | automatic once fs is real        |
| Calendar events       | `FileSystem` (`~/.local/share/calendar/events.json`) | automatic; format documented in `apps/calendar/store.ts` |

Steps: implement the interface, register it in `os/services/index.ts`. No app changes.
Filesystem calls are all async and take absolute POSIX paths; `subscribe` is the hook for
change notifications (inotify-style). Unknown values are `null` and shown as "Not available".

Not yet backed by anything (stored or shown only): keyboard layout/repeat, display
resolution apply, clock setting, shutdown/restart. Each says so in the UI.

## Porting notes

* The window manager store is framework-independent state (rects, z-order, focus,
  minimise/maximise). A native compositor can reuse its logic and rules one-to-one.
* Colours are 12 CSS variables (`src/index.css`); the design is monochrome and
  selection is inversion, so a native theme is a handful of constants.
* Icons are 16×16 stroke paths in `ui/Icon.tsx` — trivially rasterisable.
* Date/time formatting avoids `Intl`, the calculator avoids `eval`, paths avoid `node:path`.

## Footprint

Runtime dependency: React only (plus `clsx`/`tailwind-merge`, already in the template, used for a
tiny class helper). No UI kit, router, state library or icon pack. Tailwind is compile-time only.
Check size with `npm run build` and look at the single `dist/index.html`.

## Shortcuts

Alt+Space launcher · Alt+Tab / Alt+N next window · Alt+W close · Alt+M minimise ·
Alt+Enter maximise · Alt+H hide/show all · Alt+1…9 launch app. App-level keys are listed in
each app (Files: arrows, Enter, F2, Del, Ctrl+C/X/V/A/H, Backspace, Alt+←/→;
Calendar: arrows, PageUp/Down, T; Calculator: digits, operators, Enter, Backspace, Esc;
Text: Ctrl+S).
